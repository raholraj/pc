class CodeSnippet {
  final String id;
  final String title;
  final String category;
  final String code;
  final String description;

  const CodeSnippet({
    required this.id,
    required this.title,
    required this.category,
    required this.code,
    required this.description,
  });

  String get preview {
    final lines = code.trim().split('\n');
    return lines.take(3).join('\n');
  }
}

const List<String> kSnippetCategories = [
  'All',
  'Basic',
  'OOP',
  'STL',
  'Algorithms',
  'Data Structures',
];

final List<CodeSnippet> kCodeSnippets = [
  const CodeSnippet(
    id: 'hello_world',
    title: 'Hello World',
    category: 'Basic',
    description: 'Simple Hello World program',
    code: '''#include <iostream>
using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}
''',
  ),
  const CodeSnippet(
    id: 'hello_input',
    title: 'Hello with Input',
    category: 'Basic',
    description: 'Read user name and greet them',
    code: '''#include <iostream>
using namespace std;

int main() {
    string name;
    cout << "Enter your name: ";
    cin >> name;
    cout << "Hello, " << name << "!" << endl;
    return 0;
}
''',
  ),
  const CodeSnippet(
    id: 'class_template',
    title: 'Class Template',
    category: 'OOP',
    description: 'Basic class with constructor and methods',
    code: '''#include <iostream>
using namespace std;

class Animal {
private:
    string name;
    int age;
public:
    Animal(string n, int a) : name(n), age(a) {}
    void speak() { cout << name << " says hello!" << endl; }
    string getName() const { return name; }
};

int main() {
    Animal dog("Rex", 3);
    dog.speak();
    return 0;
}
''',
  ),
  const CodeSnippet(
    id: 'vector_ops',
    title: 'Vector Operations',
    category: 'STL',
    description: 'Sort and find min/max in vector',
    code: '''#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    vector<int> nums = {5, 3, 8, 1, 9, 2};
    sort(nums.begin(), nums.end());
    for (int n : nums) cout << n << " ";
    cout << endl;
    cout << "Min: " << *min_element(nums.begin(), nums.end());
    cout << " Max: " << *max_element(nums.begin(), nums.end());
    return 0;
}
''',
  ),
  const CodeSnippet(
    id: 'map_dict',
    title: 'Map / Dictionary',
    category: 'STL',
    description: 'Ordered map with structured bindings',
    code: '''#include <iostream>
#include <map>
using namespace std;

int main() {
    map<string, int> scores;
    scores["Alice"] = 95;
    scores["Bob"] = 87;
    scores["Charlie"] = 92;
    for (auto& [name, score] : scores) {
        cout << name << ": " << score << endl;
    }
    return 0;
}
''',
  ),
  const CodeSnippet(
    id: 'fibonacci',
    title: 'Fibonacci',
    category: 'Algorithms',
    description: 'Recursive Fibonacci sequence',
    code: '''#include <iostream>
using namespace std;

int fibonacci(int n) {
    if (n <= 1) return n;
    return fibonacci(n - 1) + fibonacci(n - 2);
}

int main() {
    for (int i = 0; i < 10; i++) {
        cout << fibonacci(i) << " ";
    }
    cout << endl;
    return 0;
}
''',
  ),
  const CodeSnippet(
    id: 'binary_search',
    title: 'Binary Search',
    category: 'Algorithms',
    description: 'Binary search on sorted array',
    code: '''#include <iostream>
#include <vector>
using namespace std;

int binarySearch(vector<int>& arr, int target) {
    int left = 0, right = arr.size() - 1;
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (arr[mid] == target) return mid;
        if (arr[mid] < target) left = mid + 1;
        else right = mid - 1;
    }
    return -1;
}

int main() {
    vector<int> arr = {1, 3, 5, 7, 9, 11, 13};
    int target = 7;
    int result = binarySearch(arr, target);
    if (result != -1) cout << "Found at index: " << result;
    else cout << "Not found";
    return 0;
}
''',
  ),
  const CodeSnippet(
    id: 'stack_usage',
    title: 'Stack Usage',
    category: 'Data Structures',
    description: 'Standard stack push/pop/top',
    code: '''#include <iostream>
#include <stack>
using namespace std;

int main() {
    stack<int> st;
    st.push(10);
    st.push(20);
    st.push(30);
    cout << "Top: " << st.top() << endl;
    st.pop();
    cout << "After pop, Top: " << st.top() << endl;
    cout << "Size: " << st.size() << endl;
    return 0;
}
''',
  ),
  const CodeSnippet(
    id: 'linked_list',
    title: 'Linked List',
    category: 'Data Structures',
    description: 'Custom singly linked list implementation',
    code: '''#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node(int val) : data(val), next(nullptr) {}
};

class LinkedList {
    Node* head = nullptr;
public:
    void push(int val) {
        Node* node = new Node(val);
        node->next = head;
        head = node;
    }
    void print() {
        Node* curr = head;
        while (curr) {
            cout << curr->data << " -> ";
            curr = curr->next;
        }
        cout << "NULL" << endl;
    }
};

int main() {
    LinkedList list;
    list.push(3); list.push(2); list.push(1);
    list.print();
    return 0;
}
''',
  ),
  const CodeSnippet(
    id: 'string_stream',
    title: 'String Stream',
    category: 'Basic',
    description: 'Read lines from string stream (simulates file I/O)',
    code: '''#include <iostream>
#include <sstream>
#include <string>
using namespace std;

int main() {
    // Simulating file content as string stream
    string fileContent = "Line 1\\nLine 2\\nLine 3\\n";
    istringstream stream(fileContent);
    string line;
    int lineNum = 1;
    while (getline(stream, line)) {
        cout << lineNum++ << ": " << line << endl;
    }
    return 0;
}
''',
  ),
  const CodeSnippet(
    id: 'polymorphism',
    title: 'Inheritance & Polymorphism',
    category: 'OOP',
    description: 'Abstract base class with virtual methods',
    code: '''#include <iostream>
using namespace std;

class Shape {
public:
    virtual double area() = 0;
    virtual void describe() {
        cout << "Area: " << area() << endl;
    }
};

class Circle : public Shape {
    double radius;
public:
    Circle(double r) : radius(r) {}
    double area() override { return 3.14159 * radius * radius; }
};

class Rectangle : public Shape {
    double w, h;
public:
    Rectangle(double w, double h) : w(w), h(h) {}
    double area() override { return w * h; }
};

int main() {
    Shape* shapes[] = { new Circle(5), new Rectangle(4, 6) };
    for (Shape* s : shapes) s->describe();
    return 0;
}
''',
  ),
  const CodeSnippet(
    id: 'string_manip',
    title: 'String Manipulation',
    category: 'STL',
    description: 'Transform, substr, find operations on strings',
    code: '''#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

int main() {
    string s = "Hello, World!";
    cout << "Original: " << s << endl;
    cout << "Length: " << s.length() << endl;
    cout << "Upper: ";
    transform(s.begin(), s.end(), s.begin(), ::toupper);
    cout << s << endl;
    cout << "Substr: " << s.substr(0, 5) << endl;
    cout << "Find \\'WORLD\\': " << s.find("WORLD") << endl;
    return 0;
}
''',
  ),
];
