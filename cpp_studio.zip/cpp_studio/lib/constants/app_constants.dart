import 'package:flutter/material.dart';

class AppColors {
  // App shell
  static const Color editorBg = Color(0xFF1E1E1E);
  static const Color sidebarBg = Color(0xFF252526);
  static const Color tabBarBg = Color(0xFF2D2D2D);
  static const Color activeTabBg = Color(0xFF1E1E1E);
  static const Color activeTabBorder = Color(0xFF007ACC);
  static const Color inactiveTabBg = Color(0xFF2D2D2D);
  static const Color defaultText = Color(0xFFD4D4D4);
  static const Color dimText = Color(0xFF858585);
  static const Color currentLineBg = Color(0xFF2A2D2E);
  static const Color selectionBg = Color(0xFF264F78);
  static const Color cursorColor = Color(0xFFAEAFAD);
  static const Color statusBarBg = Color(0xFF007ACC);
  static const Color statusBarText = Color(0xFFFFFFFF);

  // Actions
  static const Color runBtnColor = Color(0xFF23D18B);
  static const Color stopBtnColor = Color(0xFFE51400);
  static const Color errorColor = Color(0xFFF44747);
  static const Color warningColor = Color(0xFFCCA700);
  static const Color successColor = Color(0xFF23D18B);
  static const Color unsavedDot = Color(0xFFE8A838);
  static const Color findMatchBg = Color(0xFF515C6A);
  static const Color findCurrentBg = Color(0xFFF6F557);

  // C++ Syntax colors
  static const Color syntaxKeyword = Color(0xFF569CD6);
  static const Color syntaxType = Color(0xFF4EC9B0);
  static const Color syntaxString = Color(0xFFCE9178);
  static const Color syntaxComment = Color(0xFF6A9955);
  static const Color syntaxNumber = Color(0xFFB5CEA8);
  static const Color syntaxFunction = Color(0xFFDCDCAA);
  static const Color syntaxPreproc = Color(0xFFC586C0);
  static const Color syntaxVariable = Color(0xFF9CDCFE);
  static const Color syntaxOperator = Color(0xFFD4D4D4);
  static const Color syntaxBracket = Color(0xFFFFD700);

  // Gradient
  static const Color gradientStart = Color(0xFF005F9E);
  static const Color gradientMid = Color(0xFF007ACC);
  static const Color gradientEnd = Color(0xFF005F9E);
}

class AppSizes {
  static const double topBarHeight = 56.0;
  static const double tabBarHeight = 36.0;
  static const double statusBarHeight = 22.0;
  static const double gutterWidth = 48.0;
  static const double minBottomPanelHeight = 80.0;
  static const double defaultBottomPanelHeight = 220.0;
  static const double maxBottomPanelHeightRatio = 0.5;
  static const double drawerWidth = 280.0;
  static const double runBtnWidth = 72.0;
  static const double iconBtnSize = 40.0;
  static const double activeTabBorderWidth = 2.0;
  static const double maxTabs = 5;
  static const double tabMinWidth = 80.0;
  static const double tabMaxWidth = 160.0;
  static const double resizeHandleHeight = 6.0;
}

class AppStrings {
  static const String appName = 'C++ Studio';
  static const String appVersion = '1.0.0';
  static const String wandboxUrl = 'https://wandbox.org/api/compile.json';
  static const String wandboxBaseUrl = 'https://wandbox.org';
  static const String defaultFileName = 'main.cpp';
  static const String defaultCompiler = 'gcc-13.2.0';
  static const String defaultStandard = 'c++17';
  static const String defaultFlags = '-Wall -O2';
  static const String defaultEncoding = 'UTF-8';

  static const String noInternetError = 'No internet connection. Check your network.';
  static const String timeoutError = 'Compilation timed out (30s limit).';
  static const String apiError = 'API error: check your connection and try again.';
  static const String unexpectedError = 'Unexpected error. Please try again.';
  static const String maxTabsError = 'Close a tab first (max 5 tabs).';
  static const String nothingToUndo = 'Nothing to undo';
  static const String nothingToRedo = 'Nothing to redo';

  static const String autoSaveKey = 'auto_save';
  static const String settingsKey = 'app_settings';
  static const String recentFilesKey = 'recent_files';
  static const String sessionKey = 'last_session';
  static const String bottomPanelHeightKey = 'bottom_panel_height';
}

class AppCompilers {
  static const List<Map<String, String>> compilers = [
    {'name': 'GCC 13.2.0 (Latest)', 'value': 'gcc-13.2.0', 'display': 'GCC 13.2'},
    {'name': 'GCC 12.2.0', 'value': 'gcc-12.2.0', 'display': 'GCC 12.2'},
    {'name': 'GCC 11.3.0', 'value': 'gcc-11.3.0', 'display': 'GCC 11.3'},
    {'name': 'Clang 17.0.1 (Latest)', 'value': 'clang-17.0.1', 'display': 'Clang 17'},
    {'name': 'Clang 16.0.6', 'value': 'clang-16.0.6', 'display': 'Clang 16'},
  ];

  static const List<Map<String, String>> standards = [
    {'name': 'C++11', 'value': 'c++11', 'option': 'warning,c++11'},
    {'name': 'C++14', 'value': 'c++14', 'option': 'warning,c++14'},
    {'name': 'C++17', 'value': 'c++17', 'option': 'warning,c++17'},
    {'name': 'C++20', 'value': 'c++20', 'option': 'warning,c++2a'},
    {'name': 'C++23', 'value': 'c++23', 'option': 'warning,c++2b'},
  ];

  static String getOption(String standard) {
    final found = standards.firstWhere(
      (s) => s['value'] == standard,
      orElse: () => {'option': 'warning,c++17'},
    );
    return found['option'] ?? 'warning,c++17';
  }

  static String getCompilerDisplay(String compiler) {
    final found = compilers.firstWhere(
      (c) => c['value'] == compiler,
      orElse: () => {'display': 'GCC 13.2'},
    );
    return found['display'] ?? 'GCC 13.2';
  }
}

class AppFonts {
  static const List<String> fontFamilies = [
    'JetBrains Mono',
    'Fira Code',
    'Courier New',
  ];

  static const List<double> fontSizes = [
    10, 11, 12, 13, 14, 15, 16, 18, 20, 22, 24
  ];

  static const List<int> tabSizes = [2, 4, 8];
}

const String kDefaultCppTemplate = '''#include <iostream>
using namespace std;

int main() {
    // Your code here
    
    return 0;
}
''';
