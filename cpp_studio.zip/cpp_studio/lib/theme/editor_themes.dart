import 'package:flutter/material.dart';

enum EditorThemeType {
  vsDarkPlus,
  vsLight,
  monokai,
  dracula,
  oneDarkPro,
  solarizedDark,
}

class EditorThemeData {
  final String name;
  final EditorThemeType type;
  final Color background;
  final Color sidebarBg;
  final Color tabBarBg;
  final Color activeTabBg;
  final Color activeTabBorder;
  final Color defaultText;
  final Color dimText;
  final Color currentLineBg;
  final Color selectionBg;
  final Color cursorColor;
  final Color statusBarBg;
  final Color lineNumberBg;
  final Map<String, TextStyle> syntaxStyles;
  final Color previewColor1;
  final Color previewColor2;

  const EditorThemeData({
    required this.name,
    required this.type,
    required this.background,
    required this.sidebarBg,
    required this.tabBarBg,
    required this.activeTabBg,
    required this.activeTabBorder,
    required this.defaultText,
    required this.dimText,
    required this.currentLineBg,
    required this.selectionBg,
    required this.cursorColor,
    required this.statusBarBg,
    required this.lineNumberBg,
    required this.syntaxStyles,
    required this.previewColor1,
    required this.previewColor2,
  });
}

class EditorThemes {
  static const EditorThemeData vsDarkPlus = EditorThemeData(
    name: 'VS Dark+',
    type: EditorThemeType.vsDarkPlus,
    background: Color(0xFF1E1E1E),
    sidebarBg: Color(0xFF252526),
    tabBarBg: Color(0xFF2D2D2D),
    activeTabBg: Color(0xFF1E1E1E),
    activeTabBorder: Color(0xFF007ACC),
    defaultText: Color(0xFFD4D4D4),
    dimText: Color(0xFF858585),
    currentLineBg: Color(0xFF2A2D2E),
    selectionBg: Color(0xFF264F78),
    cursorColor: Color(0xFFAEAFAD),
    statusBarBg: Color(0xFF007ACC),
    lineNumberBg: Color(0xFF1E1E1E),
    previewColor1: Color(0xFF1E1E1E),
    previewColor2: Color(0xFF007ACC),
    syntaxStyles: {
      'root': TextStyle(color: Color(0xFFD4D4D4), backgroundColor: Color(0xFF1E1E1E)),
      'keyword': TextStyle(color: Color(0xFF569CD6)),
      'built_in': TextStyle(color: Color(0xFF4EC9B0)),
      'type': TextStyle(color: Color(0xFF4EC9B0)),
      'class': TextStyle(color: Color(0xFF4EC9B0)),
      'string': TextStyle(color: Color(0xFFCE9178)),
      'comment': TextStyle(color: Color(0xFF6A9955), fontStyle: FontStyle.italic),
      'number': TextStyle(color: Color(0xFFB5CEA8)),
      'title': TextStyle(color: Color(0xFFDCDCAA)),
      'function': TextStyle(color: Color(0xFFDCDCAA)),
      'meta': TextStyle(color: Color(0xFFC586C0)),
      'variable': TextStyle(color: Color(0xFF9CDCFE)),
      'params': TextStyle(color: Color(0xFF9CDCFE)),
      'attr': TextStyle(color: Color(0xFF9CDCFE)),
      'literal': TextStyle(color: Color(0xFF569CD6)),
      'operator': TextStyle(color: Color(0xFFD4D4D4)),
      'punctuation': TextStyle(color: Color(0xFFD4D4D4)),
      'section': TextStyle(color: Color(0xFFDCDCAA)),
      'tag': TextStyle(color: Color(0xFF569CD6)),
      'name': TextStyle(color: Color(0xFF9CDCFE)),
      'symbol': TextStyle(color: Color(0xFFB5CEA8)),
    },
  );

  static const EditorThemeData monokai = EditorThemeData(
    name: 'Monokai',
    type: EditorThemeType.monokai,
    background: Color(0xFF272822),
    sidebarBg: Color(0xFF1E1E1B),
    tabBarBg: Color(0xFF3E3D32),
    activeTabBg: Color(0xFF272822),
    activeTabBorder: Color(0xFFAE81FF),
    defaultText: Color(0xFFF8F8F2),
    dimText: Color(0xFF75715E),
    currentLineBg: Color(0xFF3E3D32),
    selectionBg: Color(0xFF49483E),
    cursorColor: Color(0xFFF8F8F0),
    statusBarBg: Color(0xFFAE81FF),
    lineNumberBg: Color(0xFF272822),
    previewColor1: Color(0xFF272822),
    previewColor2: Color(0xFFAE81FF),
    syntaxStyles: {
      'root': TextStyle(color: Color(0xFFF8F8F2), backgroundColor: Color(0xFF272822)),
      'keyword': TextStyle(color: Color(0xFFF92672)),
      'built_in': TextStyle(color: Color(0xFF66D9E8)),
      'type': TextStyle(color: Color(0xFF66D9E8)),
      'class': TextStyle(color: Color(0xFFA6E22E)),
      'string': TextStyle(color: Color(0xFFE6DB74)),
      'comment': TextStyle(color: Color(0xFF75715E), fontStyle: FontStyle.italic),
      'number': TextStyle(color: Color(0xFFAE81FF)),
      'title': TextStyle(color: Color(0xFFA6E22E)),
      'function': TextStyle(color: Color(0xFFA6E22E)),
      'meta': TextStyle(color: Color(0xFFF92672)),
      'variable': TextStyle(color: Color(0xFFF8F8F2)),
      'params': TextStyle(color: Color(0xFFFD971F)),
      'attr': TextStyle(color: Color(0xFFA6E22E)),
      'literal': TextStyle(color: Color(0xFFAE81FF)),
      'operator': TextStyle(color: Color(0xFFF8F8F2)),
      'punctuation': TextStyle(color: Color(0xFFF8F8F2)),
      'section': TextStyle(color: Color(0xFFA6E22E)),
      'tag': TextStyle(color: Color(0xFFF92672)),
      'name': TextStyle(color: Color(0xFFA6E22E)),
      'symbol': TextStyle(color: Color(0xFFAE81FF)),
    },
  );

  static const EditorThemeData dracula = EditorThemeData(
    name: 'Dracula',
    type: EditorThemeType.dracula,
    background: Color(0xFF282A36),
    sidebarBg: Color(0xFF21222C),
    tabBarBg: Color(0xFF21222C),
    activeTabBg: Color(0xFF282A36),
    activeTabBorder: Color(0xFFBD93F9),
    defaultText: Color(0xFFF8F8F2),
    dimText: Color(0xFF6272A4),
    currentLineBg: Color(0xFF44475A),
    selectionBg: Color(0xFF44475A),
    cursorColor: Color(0xFFF8F8F2),
    statusBarBg: Color(0xFFBD93F9),
    lineNumberBg: Color(0xFF282A36),
    previewColor1: Color(0xFF282A36),
    previewColor2: Color(0xFFBD93F9),
    syntaxStyles: {
      'root': TextStyle(color: Color(0xFFF8F8F2), backgroundColor: Color(0xFF282A36)),
      'keyword': TextStyle(color: Color(0xFFFF79C6)),
      'built_in': TextStyle(color: Color(0xFF8BE9FD)),
      'type': TextStyle(color: Color(0xFF8BE9FD)),
      'class': TextStyle(color: Color(0xFF50FA7B)),
      'string': TextStyle(color: Color(0xFFF1FA8C)),
      'comment': TextStyle(color: Color(0xFF6272A4), fontStyle: FontStyle.italic),
      'number': TextStyle(color: Color(0xFFBD93F9)),
      'title': TextStyle(color: Color(0xFF50FA7B)),
      'function': TextStyle(color: Color(0xFF50FA7B)),
      'meta': TextStyle(color: Color(0xFFFF79C6)),
      'variable': TextStyle(color: Color(0xFFF8F8F2)),
      'params': TextStyle(color: Color(0xFFFFB86C)),
      'attr': TextStyle(color: Color(0xFF50FA7B)),
      'literal': TextStyle(color: Color(0xFFBD93F9)),
      'operator': TextStyle(color: Color(0xFFFF79C6)),
      'punctuation': TextStyle(color: Color(0xFFF8F8F2)),
      'section': TextStyle(color: Color(0xFF50FA7B)),
      'tag': TextStyle(color: Color(0xFFFF79C6)),
      'name': TextStyle(color: Color(0xFF50FA7B)),
      'symbol': TextStyle(color: Color(0xFFBD93F9)),
    },
  );

  static const EditorThemeData oneDarkPro = EditorThemeData(
    name: 'One Dark Pro',
    type: EditorThemeType.oneDarkPro,
    background: Color(0xFF282C34),
    sidebarBg: Color(0xFF21252B),
    tabBarBg: Color(0xFF21252B),
    activeTabBg: Color(0xFF282C34),
    activeTabBorder: Color(0xFF61AFEF),
    defaultText: Color(0xFFABB2BF),
    dimText: Color(0xFF5C6370),
    currentLineBg: Color(0xFF2C313A),
    selectionBg: Color(0xFF3E4451),
    cursorColor: Color(0xFF528BFF),
    statusBarBg: Color(0xFF61AFEF),
    lineNumberBg: Color(0xFF282C34),
    previewColor1: Color(0xFF282C34),
    previewColor2: Color(0xFF61AFEF),
    syntaxStyles: {
      'root': TextStyle(color: Color(0xFFABB2BF), backgroundColor: Color(0xFF282C34)),
      'keyword': TextStyle(color: Color(0xFFC678DD)),
      'built_in': TextStyle(color: Color(0xFFE5C07B)),
      'type': TextStyle(color: Color(0xFFE5C07B)),
      'class': TextStyle(color: Color(0xFFE5C07B)),
      'string': TextStyle(color: Color(0xFF98C379)),
      'comment': TextStyle(color: Color(0xFF5C6370), fontStyle: FontStyle.italic),
      'number': TextStyle(color: Color(0xFFD19A66)),
      'title': TextStyle(color: Color(0xFF61AFEF)),
      'function': TextStyle(color: Color(0xFF61AFEF)),
      'meta': TextStyle(color: Color(0xFFE06C75)),
      'variable': TextStyle(color: Color(0xFFE06C75)),
      'params': TextStyle(color: Color(0xFFD19A66)),
      'attr': TextStyle(color: Color(0xFF98C379)),
      'literal': TextStyle(color: Color(0xFF56B6C2)),
      'operator': TextStyle(color: Color(0xFF56B6C2)),
      'punctuation': TextStyle(color: Color(0xFFABB2BF)),
      'section': TextStyle(color: Color(0xFF61AFEF)),
      'tag': TextStyle(color: Color(0xFFE06C75)),
      'name': TextStyle(color: Color(0xFFE06C75)),
      'symbol': TextStyle(color: Color(0xFF56B6C2)),
    },
  );

  static const EditorThemeData vsLight = EditorThemeData(
    name: 'VS Light',
    type: EditorThemeType.vsLight,
    background: Color(0xFFFFFFFF),
    sidebarBg: Color(0xFFF3F3F3),
    tabBarBg: Color(0xFFECECEC),
    activeTabBg: Color(0xFFFFFFFF),
    activeTabBorder: Color(0xFF007ACC),
    defaultText: Color(0xFF000000),
    dimText: Color(0xFF237893),
    currentLineBg: Color(0xFFEAF5FB),
    selectionBg: Color(0xFFADD6FF),
    cursorColor: Color(0xFF000000),
    statusBarBg: Color(0xFF007ACC),
    lineNumberBg: Color(0xFFFFFFFF),
    previewColor1: Color(0xFFFFFFFF),
    previewColor2: Color(0xFF007ACC),
    syntaxStyles: {
      'root': TextStyle(color: Color(0xFF000000), backgroundColor: Color(0xFFFFFFFF)),
      'keyword': TextStyle(color: Color(0xFF0000FF)),
      'built_in': TextStyle(color: Color(0xFF267F99)),
      'type': TextStyle(color: Color(0xFF267F99)),
      'class': TextStyle(color: Color(0xFF267F99)),
      'string': TextStyle(color: Color(0xFFA31515)),
      'comment': TextStyle(color: Color(0xFF008000), fontStyle: FontStyle.italic),
      'number': TextStyle(color: Color(0xFF098658)),
      'title': TextStyle(color: Color(0xFF795E26)),
      'function': TextStyle(color: Color(0xFF795E26)),
      'meta': TextStyle(color: Color(0xFF800080)),
      'variable': TextStyle(color: Color(0xFF001080)),
      'params': TextStyle(color: Color(0xFF001080)),
      'attr': TextStyle(color: Color(0xFF001080)),
      'literal': TextStyle(color: Color(0xFF0000FF)),
      'operator': TextStyle(color: Color(0xFF000000)),
      'punctuation': TextStyle(color: Color(0xFF000000)),
      'section': TextStyle(color: Color(0xFF795E26)),
      'tag': TextStyle(color: Color(0xFF800000)),
      'name': TextStyle(color: Color(0xFF800000)),
      'symbol': TextStyle(color: Color(0xFF098658)),
    },
  );

  static const EditorThemeData solarizedDark = EditorThemeData(
    name: 'Solarized Dark',
    type: EditorThemeType.solarizedDark,
    background: Color(0xFF002B36),
    sidebarBg: Color(0xFF073642),
    tabBarBg: Color(0xFF073642),
    activeTabBg: Color(0xFF002B36),
    activeTabBorder: Color(0xFF268BD2),
    defaultText: Color(0xFF839496),
    dimText: Color(0xFF657B83),
    currentLineBg: Color(0xFF073642),
    selectionBg: Color(0xFF073642),
    cursorColor: Color(0xFF839496),
    statusBarBg: Color(0xFF268BD2),
    lineNumberBg: Color(0xFF002B36),
    previewColor1: Color(0xFF002B36),
    previewColor2: Color(0xFF268BD2),
    syntaxStyles: {
      'root': TextStyle(color: Color(0xFF839496), backgroundColor: Color(0xFF002B36)),
      'keyword': TextStyle(color: Color(0xFF859900)),
      'built_in': TextStyle(color: Color(0xFF2AA198)),
      'type': TextStyle(color: Color(0xFF2AA198)),
      'class': TextStyle(color: Color(0xFF268BD2)),
      'string': TextStyle(color: Color(0xFF2AA198)),
      'comment': TextStyle(color: Color(0xFF586E75), fontStyle: FontStyle.italic),
      'number': TextStyle(color: Color(0xFFD33682)),
      'title': TextStyle(color: Color(0xFF268BD2)),
      'function': TextStyle(color: Color(0xFF268BD2)),
      'meta': TextStyle(color: Color(0xFFCB4B16)),
      'variable': TextStyle(color: Color(0xFF268BD2)),
      'params': TextStyle(color: Color(0xFF839496)),
      'attr': TextStyle(color: Color(0xFF657B83)),
      'literal': TextStyle(color: Color(0xFFD33682)),
      'operator': TextStyle(color: Color(0xFF859900)),
      'punctuation': TextStyle(color: Color(0xFF839496)),
      'section': TextStyle(color: Color(0xFF268BD2)),
      'tag': TextStyle(color: Color(0xFF859900)),
      'name': TextStyle(color: Color(0xFF268BD2)),
      'symbol': TextStyle(color: Color(0xFFD33682)),
    },
  );

  static EditorThemeData fromString(String name) {
    switch (name) {
      case 'monokai':
        return monokai;
      case 'dracula':
        return dracula;
      case 'oneDarkPro':
        return oneDarkPro;
      case 'vsLight':
        return vsLight;
      case 'solarizedDark':
        return solarizedDark;
      default:
        return vsDarkPlus;
    }
  }

  static List<EditorThemeData> get allThemes => [
        vsDarkPlus,
        vsLight,
        monokai,
        dracula,
        oneDarkPro,
        solarizedDark,
      ];
}
