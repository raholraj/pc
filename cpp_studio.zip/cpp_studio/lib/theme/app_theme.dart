import 'package:flutter/material.dart';
import '../constants/app_constants.dart';

class AppTheme {
  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.editorBg,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.activeTabBorder,
        secondary: AppColors.runBtnColor,
        surface: AppColors.sidebarBg,
        error: AppColors.errorColor,
        onPrimary: Colors.white,
        onSecondary: Colors.black,
        onSurface: AppColors.defaultText,
        onError: Colors.white,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.gradientMid,
        foregroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
      ),
      drawerTheme: const DrawerThemeData(
        backgroundColor: AppColors.sidebarBg,
        width: AppSizes.drawerWidth,
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: AppColors.sidebarBg,
        modalBackgroundColor: AppColors.sidebarBg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
        ),
      ),
      listTileTheme: const ListTileThemeData(
        textColor: AppColors.defaultText,
        iconColor: AppColors.dimText,
      ),
      iconTheme: const IconThemeData(
        color: AppColors.defaultText,
        size: 20,
      ),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: AppColors.defaultText),
        bodyMedium: TextStyle(color: AppColors.defaultText),
        bodySmall: TextStyle(color: AppColors.dimText),
        labelLarge: TextStyle(color: AppColors.defaultText),
      ),
      dividerTheme: const DividerThemeData(
        color: Color(0xFF3C3C3C),
        thickness: 1,
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return AppColors.activeTabBorder;
          }
          return AppColors.dimText;
        }),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return AppColors.activeTabBorder.withOpacity(0.5);
          }
          return const Color(0xFF3C3C3C);
        }),
      ),
      sliderTheme: const SliderThemeData(
        activeTrackColor: AppColors.activeTabBorder,
        thumbColor: AppColors.activeTabBorder,
        overlayColor: Color(0x29007ACC),
        inactiveTrackColor: Color(0xFF3C3C3C),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: AppColors.tabBarBg,
        selectedColor: AppColors.activeTabBorder.withOpacity(0.3),
        labelStyle: const TextStyle(color: AppColors.defaultText, fontSize: 12),
        side: const BorderSide(color: Color(0xFF3C3C3C)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
      ),
      snackBarTheme: const SnackBarThemeData(
        backgroundColor: Color(0xFF3C3C3C),
        contentTextStyle: TextStyle(color: AppColors.defaultText),
        behavior: SnackBarBehavior.floating,
      ),
      dialogTheme: const DialogTheme(
        backgroundColor: AppColors.sidebarBg,
        titleTextStyle: TextStyle(
          color: AppColors.defaultText,
          fontSize: 18,
          fontWeight: FontWeight.w600,
        ),
        contentTextStyle: TextStyle(color: AppColors.dimText),
      ),
      inputDecorationTheme: const InputDecorationTheme(
        filled: true,
        fillColor: AppColors.editorBg,
        border: OutlineInputBorder(
          borderSide: BorderSide(color: Color(0xFF3C3C3C)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Color(0xFF3C3C3C)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: AppColors.activeTabBorder),
        ),
        hintStyle: TextStyle(color: AppColors.dimText),
        labelStyle: TextStyle(color: AppColors.dimText),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.activeTabBorder,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: AppColors.activeTabBorder,
        ),
      ),
    );
  }

  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      colorScheme: ColorScheme.light(
        primary: AppColors.activeTabBorder,
        secondary: AppColors.runBtnColor,
        error: AppColors.errorColor,
      ),
    );
  }
}
