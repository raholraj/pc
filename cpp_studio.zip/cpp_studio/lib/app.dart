import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/settings_provider.dart';
import 'screens/editor_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/snippets_screen.dart';
import 'theme/app_theme.dart';

class CppStudioApp extends StatelessWidget {
  const CppStudioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, _) {
        return MaterialApp(
          title: 'C++ Studio',
          debugShowCheckedModeBanner: false,
          themeMode: settings.isDarkTheme ? ThemeMode.dark : ThemeMode.light,
          theme: AppTheme.lightTheme,
          darkTheme: AppTheme.darkTheme,
          initialRoute: '/',
          routes: {
            '/': (context) => const EditorScreen(),
            '/settings': (context) => const SettingsScreen(),
            '/snippets': (context) => const SnippetsScreen(),
          },
        );
      },
    );
  }
}
