import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_settings.dart';
import '../models/code_file.dart';
import '../constants/app_constants.dart';

class StorageService {
  static SharedPreferences? _prefs;

  static Future<void> init() async {
    _prefs ??= await SharedPreferences.getInstance();
  }

  static SharedPreferences get prefs {
    if (_prefs == null) throw StateError('StorageService not initialized');
    return _prefs!;
  }

  // ─── Settings ─────────────────────────────────────────────────────────
  static Future<void> saveSettings(AppSettings settings) async {
    await init();
    try {
      await prefs.setString(AppStrings.settingsKey, jsonEncode(settings.toJson()));
    } catch (_) {}
  }

  static Future<AppSettings> loadSettings() async {
    await init();
    try {
      final json = prefs.getString(AppStrings.settingsKey);
      if (json != null) {
        return AppSettings.fromJson(jsonDecode(json) as Map<String, dynamic>);
      }
    } catch (_) {}
    return AppSettings.defaults();
  }

  // ─── File Content ──────────────────────────────────────────────────────
  static Future<void> saveFileContent(String fileId, String content) async {
    await init();
    try {
      await prefs.setString('file_content_$fileId', content);
    } catch (_) {}
  }

  static Future<String?> loadFileContent(String fileId) async {
    await init();
    try {
      return prefs.getString('file_content_$fileId');
    } catch (_) {
      return null;
    }
  }

  static Future<void> deleteFileContent(String fileId) async {
    await init();
    try {
      await prefs.remove('file_content_$fileId');
    } catch (_) {}
  }

  // ─── Session ──────────────────────────────────────────────────────────
  static Future<void> saveSession({
    required List<CodeFile> openFiles,
    required int activeFileIndex,
  }) async {
    await init();
    try {
      final sessionData = {
        'openFiles': openFiles.map((f) => f.toJson()).toList(),
        'activeFileIndex': activeFileIndex,
        'timestamp': DateTime.now().toIso8601String(),
      };
      await prefs.setString(AppStrings.sessionKey, jsonEncode(sessionData));

      for (final file in openFiles) {
        await saveFileContent(file.id, file.content);
      }
    } catch (_) {}
  }

  static Future<Map<String, dynamic>?> loadSession() async {
    await init();
    try {
      final json = prefs.getString(AppStrings.sessionKey);
      if (json != null) {
        return jsonDecode(json) as Map<String, dynamic>;
      }
    } catch (_) {}
    return null;
  }

  // ─── Recent Files ──────────────────────────────────────────────────────
  static Future<void> saveRecentFiles(List<String> filePaths) async {
    await init();
    try {
      await prefs.setStringList(AppStrings.recentFilesKey, filePaths.take(10).toList());
    } catch (_) {}
  }

  static Future<List<String>> loadRecentFiles() async {
    await init();
    try {
      return prefs.getStringList(AppStrings.recentFilesKey) ?? [];
    } catch (_) {
      return [];
    }
  }

  static Future<void> addRecentFile(String filePath) async {
    final recent = await loadRecentFiles();
    recent.remove(filePath);
    recent.insert(0, filePath);
    await saveRecentFiles(recent.take(10).toList());
  }

  // ─── Panel Height ──────────────────────────────────────────────────────
  static Future<void> saveBottomPanelHeight(double height) async {
    await init();
    try {
      await prefs.setDouble(AppStrings.bottomPanelHeightKey, height);
    } catch (_) {}
  }

  static Future<double> loadBottomPanelHeight() async {
    await init();
    try {
      return prefs.getDouble(AppStrings.bottomPanelHeightKey) ??
          AppSizes.defaultBottomPanelHeight;
    } catch (_) {
      return AppSizes.defaultBottomPanelHeight;
    }
  }

  // ─── Generic ──────────────────────────────────────────────────────────
  static Future<void> setString(String key, String value) async {
    await init();
    try {
      await prefs.setString(key, value);
    } catch (_) {}
  }

  static Future<String?> getString(String key) async {
    await init();
    try {
      return prefs.getString(key);
    } catch (_) {
      return null;
    }
  }

  static Future<void> clearAll() async {
    await init();
    try {
      await prefs.clear();
    } catch (_) {}
  }
}
