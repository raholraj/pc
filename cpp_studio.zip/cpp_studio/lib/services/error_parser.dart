import '../models/compiler_error.dart';

class ErrorParser {
  // Match GCC/Clang output: filename:line:col: severity: message
  static final RegExp _errorPattern = RegExp(
    r'^(?:(?:\.\/)?(\S+\.(?:cpp|cc|cxx|h|hpp)|main)):(\d+):(\d+):\s+(error|warning|note):\s+(.+)$',
    multiLine: true,
  );

  // Simplified pattern for Wandbox which uses "main" as filename
  static final RegExp _wandboxPattern = RegExp(
    r'^(?:main|prog|source):?(\d+):(\d+):\s+(error|warning|note):\s+(.+)$',
    multiLine: true,
  );

  // Generic numbered pattern
  static final RegExp _genericPattern = RegExp(
    r'(?:^|(?<=\n))(?:.*?):?(\d+):(\d+):\s+(error|warning):\s+(.+)',
    multiLine: true,
  );

  static List<CompilerError> parse(String compilerMessage) {
    if (compilerMessage.isEmpty) return [];

    final errors = <CompilerError>[];
    final seen = <String>{};

    void addError(CompilerError err) {
      final key = '${err.line}:${err.column}:${err.severity}:${err.message}';
      if (seen.contains(key)) return;
      seen.add(key);
      errors.add(err);
    }

    // Try full filename pattern
    for (final match in _errorPattern.allMatches(compilerMessage)) {
      final file = match.group(1) ?? 'main.cpp';
      final line = int.tryParse(match.group(2) ?? '0') ?? 0;
      final col = int.tryParse(match.group(3) ?? '0') ?? 0;
      final severity = match.group(4) ?? 'error';
      final message = match.group(5) ?? '';
      final fullText = match.group(0) ?? '';

      if (line > 0 && message.isNotEmpty) {
        addError(CompilerError(
          file: file.isEmpty ? 'main.cpp' : file,
          line: line,
          column: col,
          severity: severity,
          message: _cleanMessage(message),
          fullText: fullText,
        ));
      }
    }

    // Try Wandbox pattern if nothing found
    if (errors.isEmpty) {
      for (final match in _wandboxPattern.allMatches(compilerMessage)) {
        final line = int.tryParse(match.group(1) ?? '0') ?? 0;
        final col = int.tryParse(match.group(2) ?? '0') ?? 0;
        final severity = match.group(3) ?? 'error';
        final message = match.group(4) ?? '';
        final fullText = match.group(0) ?? '';

        if (line > 0 && message.isNotEmpty) {
          addError(CompilerError(
            file: 'main.cpp',
            line: line,
            column: col,
            severity: severity,
            message: _cleanMessage(message),
            fullText: fullText,
          ));
        }
      }
    }

    // Fallback: line-by-line parsing
    if (errors.isEmpty) {
      final lines = compilerMessage.split('\n');
      for (final rawLine in lines) {
        final trimmed = rawLine.trim();
        if (trimmed.isEmpty) continue;

        // Try any pattern with digits
        final parts = trimmed.split(':');
        if (parts.length >= 4) {
          final lineNum = int.tryParse(parts[1].trim());
          final colNum = int.tryParse(parts[2].trim());
          if (lineNum != null && colNum != null) {
            final rest = parts.sublist(3).join(':').trim();
            final sevMatch = RegExp(r'^(error|warning|note):\s*(.+)').firstMatch(rest);
            if (sevMatch != null) {
              addError(CompilerError(
                file: 'main.cpp',
                line: lineNum,
                column: colNum,
                severity: sevMatch.group(1) ?? 'error',
                message: _cleanMessage(sevMatch.group(2) ?? rest),
                fullText: trimmed,
              ));
            }
          }
        }
      }
    }

    // Sort: errors first, then warnings, then notes; within each by line
    errors.sort((a, b) {
      final severityOrder = {'error': 0, 'warning': 1, 'note': 2};
      final aSev = severityOrder[a.severity] ?? 3;
      final bSev = severityOrder[b.severity] ?? 3;
      if (aSev != bSev) return aSev.compareTo(bSev);
      return a.line.compareTo(b.line);
    });

    return errors;
  }

  static String _cleanMessage(String msg) {
    // Remove ANSI escape codes
    return msg
        .replaceAll(RegExp(r'\x1B\[[0-9;]*[mGKH]'), '')
        .trim();
  }

  static int countErrors(List<CompilerError> errors) =>
      errors.where((e) => e.isError).length;

  static int countWarnings(List<CompilerError> errors) =>
      errors.where((e) => e.isWarning).length;
}
