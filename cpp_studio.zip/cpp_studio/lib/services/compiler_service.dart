import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../constants/app_constants.dart';
import '../models/compilation_result.dart';

class CompilerService {
  static const String _apiUrl = AppStrings.wandboxUrl;
  final http.Client _client;

  CompilerService({http.Client? client}) : _client = client ?? http.Client();

  Future<CompilationResult> compile({
    required String code,
    required String compiler,
    required String cppStandard,
    required String stdin,
    required String extraFlags,
    int timeoutSeconds = 30,
  }) async {
    final stopwatch = Stopwatch()..start();

    try {
      final options = AppCompilers.getOption(cppStandard);

      final requestBody = {
        'code': code,
        'compiler': compiler,
        'stdin': stdin,
        'options': options,
        'compiler-option-raw': extraFlags,
        'save': false,
      };

      final response = await _client
          .post(
            Uri.parse(_apiUrl),
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
            body: jsonEncode(requestBody),
          )
          .timeout(Duration(seconds: timeoutSeconds));

      stopwatch.stop();

      if (response.statusCode == 200) {
        final Map<String, dynamic> json = jsonDecode(response.body) as Map<String, dynamic>;
        return CompilationResult.fromJson(
          json,
          compilationTime: stopwatch.elapsed,
          compiler: compiler,
          standard: cppStandard,
        );
      } else {
        return CompilationResult.networkError(
          '${AppStrings.apiError} (HTTP ${response.statusCode})',
        );
      }
    } on SocketException catch (_) {
      stopwatch.stop();
      return CompilationResult.networkError(AppStrings.noInternetError);
    } on TimeoutException catch (_) {
      stopwatch.stop();
      return CompilationResult.networkError(AppStrings.timeoutError);
    } on HttpException catch (_) {
      stopwatch.stop();
      return CompilationResult.networkError(AppStrings.apiError);
    } on FormatException catch (_) {
      stopwatch.stop();
      return CompilationResult.networkError(AppStrings.unexpectedError);
    } catch (e) {
      stopwatch.stop();
      return CompilationResult.networkError('${AppStrings.unexpectedError}: ${e.toString()}');
    }
  }

  Future<List<Map<String, dynamic>>> fetchCompilers() async {
    try {
      final response = await _client
          .get(Uri.parse('${AppStrings.wandboxBaseUrl}/api/list.json'))
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final List<dynamic> json = jsonDecode(response.body) as List<dynamic>;
        return json
            .where((item) =>
                (item as Map<String, dynamic>)['language'] == 'C++')
            .map((item) => item as Map<String, dynamic>)
            .toList();
      }
    } catch (_) {}
    return [];
  }

  void dispose() {
    _client.close();
  }
}
