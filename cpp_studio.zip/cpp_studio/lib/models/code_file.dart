import 'package:flutter/foundation.dart';

class CodeFile {
  final String id;
  String name;
  String content;
  bool hasUnsavedChanges;
  DateTime lastModified;
  String? filePath;

  CodeFile({
    required this.id,
    required this.name,
    required this.content,
    this.hasUnsavedChanges = false,
    DateTime? lastModified,
    this.filePath,
  }) : lastModified = lastModified ?? DateTime.now();

  factory CodeFile.newFile({
    required String id,
    String name = 'main.cpp',
    String content = '',
  }) {
    return CodeFile(
      id: id,
      name: name,
      content: content,
      hasUnsavedChanges: false,
    );
  }

  factory CodeFile.fromJson(Map<String, dynamic> json) {
    return CodeFile(
      id: json['id'] as String,
      name: json['name'] as String,
      content: json['content'] as String,
      hasUnsavedChanges: json['hasUnsavedChanges'] as bool? ?? false,
      lastModified: json['lastModified'] != null
          ? DateTime.tryParse(json['lastModified'] as String) ?? DateTime.now()
          : DateTime.now(),
      filePath: json['filePath'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'content': content,
      'hasUnsavedChanges': hasUnsavedChanges,
      'lastModified': lastModified.toIso8601String(),
      'filePath': filePath,
    };
  }

  CodeFile copyWith({
    String? name,
    String? content,
    bool? hasUnsavedChanges,
    DateTime? lastModified,
    String? filePath,
  }) {
    return CodeFile(
      id: id,
      name: name ?? this.name,
      content: content ?? this.content,
      hasUnsavedChanges: hasUnsavedChanges ?? this.hasUnsavedChanges,
      lastModified: lastModified ?? this.lastModified,
      filePath: filePath ?? this.filePath,
    );
  }

  String get displayName => name;
  String get extension => name.contains('.') ? name.split('.').last : '';
  bool get isCppFile => extension == 'cpp' || extension == 'cc' || extension == 'cxx';
  bool get isHeaderFile => extension == 'h' || extension == 'hpp';

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CodeFile && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;

  @override
  String toString() => 'CodeFile(id: $id, name: $name)';
}

String generateFileId() {
  return DateTime.now().millisecondsSinceEpoch.toString() +
      '_${(1000 + (9999 - 1000) * (kDebugMode ? 0.5 : DateTime.now().microsecond / 1000000)).toInt()}';
}
