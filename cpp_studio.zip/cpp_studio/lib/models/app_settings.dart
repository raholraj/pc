class AppSettings {
  double fontSize;
  String fontFamily;
  int tabSize;
  bool wordWrap;
  bool autoIndent;
  bool bracketAutoClose;
  bool showLineNumbers;
  bool highlightCurrentLine;
  String theme;
  String compiler;
  String cppStandard;
  String compilerFlags;
  int timeout;

  AppSettings({
    this.fontSize = 14.0,
    this.fontFamily = 'JetBrains Mono',
    this.tabSize = 4,
    this.wordWrap = false,
    this.autoIndent = true,
    this.bracketAutoClose = true,
    this.showLineNumbers = true,
    this.highlightCurrentLine = true,
    this.theme = 'vsDarkPlus',
    this.compiler = 'gcc-13.2.0',
    this.cppStandard = 'c++17',
    this.compilerFlags = '-Wall -O2',
    this.timeout = 30,
  });

  factory AppSettings.defaults() => AppSettings();

  factory AppSettings.fromJson(Map<String, dynamic> json) {
    return AppSettings(
      fontSize: (json['fontSize'] as num?)?.toDouble() ?? 14.0,
      fontFamily: json['fontFamily'] as String? ?? 'JetBrains Mono',
      tabSize: json['tabSize'] as int? ?? 4,
      wordWrap: json['wordWrap'] as bool? ?? false,
      autoIndent: json['autoIndent'] as bool? ?? true,
      bracketAutoClose: json['bracketAutoClose'] as bool? ?? true,
      showLineNumbers: json['showLineNumbers'] as bool? ?? true,
      highlightCurrentLine: json['highlightCurrentLine'] as bool? ?? true,
      theme: json['theme'] as String? ?? 'vsDarkPlus',
      compiler: json['compiler'] as String? ?? 'gcc-13.2.0',
      cppStandard: json['cppStandard'] as String? ?? 'c++17',
      compilerFlags: json['compilerFlags'] as String? ?? '-Wall -O2',
      timeout: json['timeout'] as int? ?? 30,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'fontSize': fontSize,
      'fontFamily': fontFamily,
      'tabSize': tabSize,
      'wordWrap': wordWrap,
      'autoIndent': autoIndent,
      'bracketAutoClose': bracketAutoClose,
      'showLineNumbers': showLineNumbers,
      'highlightCurrentLine': highlightCurrentLine,
      'theme': theme,
      'compiler': compiler,
      'cppStandard': cppStandard,
      'compilerFlags': compilerFlags,
      'timeout': timeout,
    };
  }

  AppSettings copyWith({
    double? fontSize,
    String? fontFamily,
    int? tabSize,
    bool? wordWrap,
    bool? autoIndent,
    bool? bracketAutoClose,
    bool? showLineNumbers,
    bool? highlightCurrentLine,
    String? theme,
    String? compiler,
    String? cppStandard,
    String? compilerFlags,
    int? timeout,
  }) {
    return AppSettings(
      fontSize: fontSize ?? this.fontSize,
      fontFamily: fontFamily ?? this.fontFamily,
      tabSize: tabSize ?? this.tabSize,
      wordWrap: wordWrap ?? this.wordWrap,
      autoIndent: autoIndent ?? this.autoIndent,
      bracketAutoClose: bracketAutoClose ?? this.bracketAutoClose,
      showLineNumbers: showLineNumbers ?? this.showLineNumbers,
      highlightCurrentLine: highlightCurrentLine ?? this.highlightCurrentLine,
      theme: theme ?? this.theme,
      compiler: compiler ?? this.compiler,
      cppStandard: cppStandard ?? this.cppStandard,
      compilerFlags: compilerFlags ?? this.compilerFlags,
      timeout: timeout ?? this.timeout,
    );
  }

  bool get isDarkTheme => theme != 'vsLight';
}
