class CompilationResult {
  final bool success;
  final bool compilationFailed;
  final String compilerOutput;
  final String compilerError;
  final String compilerMessage;
  final String programOutput;
  final String programError;
  final String programMessage;
  final int exitCode;
  final String? signal;
  final Duration compilationTime;
  final String compiler;
  final String standard;
  final String? permlink;
  final DateTime timestamp;
  final String? errorMessage;

  const CompilationResult({
    required this.success,
    required this.compilationFailed,
    required this.compilerOutput,
    required this.compilerError,
    required this.compilerMessage,
    required this.programOutput,
    required this.programError,
    required this.programMessage,
    required this.exitCode,
    this.signal,
    required this.compilationTime,
    required this.compiler,
    required this.standard,
    this.permlink,
    required this.timestamp,
    this.errorMessage,
  });

  factory CompilationResult.fromJson(
    Map<String, dynamic> json, {
    required Duration compilationTime,
    required String compiler,
    required String standard,
  }) {
    final status = json['status']?.toString() ?? '0';
    final exitCode = int.tryParse(status) ?? 0;
    final compilerMessage = json['compiler_message']?.toString() ?? '';
    final compilationFailed = compilerMessage.contains('error:');
    final signal = json['signal']?.toString();
    final success = !compilationFailed && exitCode == 0 && (signal == null || signal.isEmpty);

    return CompilationResult(
      success: success,
      compilationFailed: compilationFailed,
      compilerOutput: json['compiler_output']?.toString() ?? '',
      compilerError: json['compiler_error']?.toString() ?? '',
      compilerMessage: compilerMessage,
      programOutput: json['program_output']?.toString() ?? '',
      programError: json['program_error']?.toString() ?? '',
      programMessage: json['program_message']?.toString() ?? '',
      exitCode: exitCode,
      signal: (signal != null && signal.isNotEmpty) ? signal : null,
      compilationTime: compilationTime,
      compiler: compiler,
      standard: standard,
      permlink: json['permlink']?.toString(),
      timestamp: DateTime.now(),
    );
  }

  factory CompilationResult.networkError(String message) {
    return CompilationResult(
      success: false,
      compilationFailed: false,
      compilerOutput: '',
      compilerError: '',
      compilerMessage: '',
      programOutput: '',
      programError: '',
      programMessage: '',
      exitCode: -1,
      compilationTime: Duration.zero,
      compiler: '',
      standard: '',
      timestamp: DateTime.now(),
      errorMessage: message,
    );
  }

  bool get hasRuntimeError => !compilationFailed && exitCode != 0;
  bool get hasCrash => signal != null && signal!.isNotEmpty;
  bool get isNetworkError => errorMessage != null;

  String get statusText {
    if (isNetworkError) return errorMessage!;
    if (compilationFailed) return 'Compilation Failed';
    if (hasCrash) return 'Program Crashed ($signal)';
    if (hasRuntimeError) return 'Runtime Error';
    return 'Success';
  }

  String get compilerDisplayName {
    if (compiler.startsWith('gcc')) return 'GCC ${compiler.replaceAll('gcc-', '')}';
    if (compiler.startsWith('clang')) return 'Clang ${compiler.replaceAll('clang-', '')}';
    return compiler;
  }
}
