class CompilerError {
  final String file;
  final int line;
  final int column;
  final String severity;
  final String message;
  final String fullText;

  const CompilerError({
    required this.file,
    required this.line,
    required this.column,
    required this.severity,
    required this.message,
    required this.fullText,
  });

  bool get isError => severity == 'error';
  bool get isWarning => severity == 'warning';
  bool get isNote => severity == 'note';

  String get displayLocation => 'line $line, col $column';

  @override
  String toString() => '$file:$line:$column: $severity: $message';

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CompilerError &&
          runtimeType == other.runtimeType &&
          file == other.file &&
          line == other.line &&
          column == other.column &&
          severity == other.severity &&
          message == other.message;

  @override
  int get hashCode =>
      file.hashCode ^ line.hashCode ^ column.hashCode ^ severity.hashCode ^ message.hashCode;
}
