import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../constants/app_constants.dart';
import '../providers/settings_provider.dart';
import '../theme/editor_themes.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.editorBg,
      appBar: AppBar(
        backgroundColor: AppColors.gradientMid,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Settings', style: TextStyle(color: Colors.white, fontSize: 16)),
        elevation: 0,
      ),
      body: Consumer<SettingsProvider>(
        builder: (context, settings, _) {
          return ListView(
            children: [
              _SectionHeader(label: 'EDITOR'),
              _FontSizeRow(settings: settings),
              _FontFamilyRow(settings: settings),
              _TabSizeRow(settings: settings),
              _ToggleRow(
                label: 'Word Wrap',
                subtitle: 'Wrap long lines',
                value: settings.wordWrap,
                onChanged: settings.setWordWrap,
              ),
              _ToggleRow(
                label: 'Auto Indent',
                subtitle: 'Smart indent on Enter',
                value: settings.autoIndent,
                onChanged: settings.setAutoIndent,
              ),
              _ToggleRow(
                label: 'Bracket Auto-Close',
                subtitle: 'Auto-insert closing bracket',
                value: settings.bracketAutoClose,
                onChanged: settings.setBracketAutoClose,
              ),
              _ToggleRow(
                label: 'Line Numbers',
                subtitle: 'Show line numbers',
                value: settings.showLineNumbers,
                onChanged: settings.setShowLineNumbers,
              ),
              _ToggleRow(
                label: 'Highlight Current Line',
                subtitle: 'Highlight active line',
                value: settings.highlightCurrentLine,
                onChanged: settings.setHighlightCurrentLine,
              ),
              _SectionHeader(label: 'THEME'),
              _ThemeGridRow(settings: settings),
              _SectionHeader(label: 'COMPILER'),
              _CompilerPickerRow(settings: settings),
              _StandardPickerRow(settings: settings),
              _CompilerFlagsRow(settings: settings),
              _TimeoutRow(settings: settings),
              _SectionHeader(label: 'ABOUT'),
              _AboutRow(
                label: 'App Version',
                value: AppStrings.appVersion,
                icon: Icons.info_outline,
              ),
              _AboutRow(
                label: 'Wandbox API',
                value: 'wandbox.org — free C++ compiler',
                icon: Icons.open_in_new,
              ),
              ListTile(
                leading: const Icon(Icons.restore, color: AppColors.dimText),
                title: const Text('Reset to Defaults', style: TextStyle(color: AppColors.errorColor)),
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      backgroundColor: AppColors.sidebarBg,
                      title: const Text('Reset Settings', style: TextStyle(color: AppColors.defaultText)),
                      content: const Text('Reset all settings to defaults?',
                          style: TextStyle(color: AppColors.dimText)),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(ctx),
                          child: const Text('Cancel', style: TextStyle(color: AppColors.dimText)),
                        ),
                        TextButton(
                          onPressed: () {
                            settings.resetToDefaults();
                            Navigator.pop(ctx);
                          },
                          child: const Text('Reset', style: TextStyle(color: AppColors.errorColor)),
                        ),
                      ],
                    ),
                  );
                },
              ),
              const SizedBox(height: 32),
            ],
          );
        },
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String label;
  const _SectionHeader({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 6),
      color: AppColors.tabBarBg,
      child: Text(label,
          style: const TextStyle(color: AppColors.dimText, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.2)),
    );
  }
}

class _FontSizeRow extends StatelessWidget {
  final SettingsProvider settings;
  const _FontSizeRow({required this.settings});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.editorBg,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Font Size', style: TextStyle(color: AppColors.defaultText, fontSize: 14)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: AppColors.activeTabBorder.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  settings.fontSize.toInt().toString(),
                  style: const TextStyle(color: AppColors.activeTabBorder, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          Row(
            children: [
              const Text('A', style: TextStyle(color: AppColors.dimText, fontSize: 10)),
              Expanded(
                child: Slider(
                  value: settings.fontSize,
                  min: 10,
                  max: 24,
                  divisions: 14,
                  onChanged: settings.setFontSize,
                  activeColor: AppColors.activeTabBorder,
                ),
              ),
              const Text('A', style: TextStyle(color: AppColors.dimText, fontSize: 18)),
            ],
          ),
        ],
      ),
    );
  }
}

class _FontFamilyRow extends StatelessWidget {
  final SettingsProvider settings;
  const _FontFamilyRow({required this.settings});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.editorBg,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Font Family', style: TextStyle(color: AppColors.defaultText, fontSize: 14)),
          const SizedBox(height: 8),
          ...AppFonts.fontFamilies.map((font) => RadioListTile<String>(
                dense: true,
                value: font,
                groupValue: settings.fontFamily,
                onChanged: (v) => settings.setFontFamily(v!),
                title: Text(font, style: const TextStyle(color: AppColors.defaultText, fontSize: 13)),
                activeColor: AppColors.activeTabBorder,
                contentPadding: EdgeInsets.zero,
              )),
          const SizedBox(height: 6),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.sidebarBg,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: const Color(0xFF3C3C3C)),
            ),
            child: Text(
              'int main() { return 0; }',
              style: _getFontStyle(settings.fontFamily, settings.fontSize),
            ),
          ),
        ],
      ),
    );
  }

  TextStyle _getFontStyle(String family, double size) {
    switch (family) {
      case 'JetBrains Mono':
        return GoogleFonts.jetBrainsMono(color: AppColors.syntaxKeyword, fontSize: size);
      case 'Fira Code':
        return GoogleFonts.firaCode(color: AppColors.syntaxKeyword, fontSize: size);
      default:
        return TextStyle(fontFamily: 'Courier New', color: AppColors.syntaxKeyword, fontSize: size);
    }
  }
}

class _TabSizeRow extends StatelessWidget {
  final SettingsProvider settings;
  const _TabSizeRow({required this.settings});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.editorBg,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text('Tab Size', style: TextStyle(color: AppColors.defaultText, fontSize: 14)),
          SegmentedButton<int>(
            segments: AppFonts.tabSizes
                .map((s) => ButtonSegment<int>(value: s, label: Text(s.toString())))
                .toList(),
            selected: {settings.tabSize},
            onSelectionChanged: (s) => settings.setTabSize(s.first),
            style: ButtonStyle(
              backgroundColor: WidgetStateProperty.resolveWith(
                (states) => states.contains(WidgetState.selected)
                    ? AppColors.activeTabBorder.withOpacity(0.3)
                    : AppColors.tabBarBg,
              ),
              foregroundColor: WidgetStateProperty.all(AppColors.defaultText),
              side: WidgetStateProperty.all(const BorderSide(color: Color(0xFF3C3C3C))),
            ),
          ),
        ],
      ),
    );
  }
}

class _ToggleRow extends StatelessWidget {
  final String label;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _ToggleRow({
    required this.label,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.editorBg,
      child: SwitchListTile(
        value: value,
        onChanged: onChanged,
        title: Text(label, style: const TextStyle(color: AppColors.defaultText, fontSize: 14)),
        subtitle: Text(subtitle, style: const TextStyle(color: AppColors.dimText, fontSize: 12)),
        activeColor: AppColors.activeTabBorder,
      ),
    );
  }
}

class _ThemeGridRow extends StatelessWidget {
  final SettingsProvider settings;
  const _ThemeGridRow({required this.settings});

  static final Map<String, String> _themeKeys = {
    'VS Dark+': 'vsDarkPlus',
    'VS Light': 'vsLight',
    'Monokai': 'monokai',
    'Dracula': 'dracula',
    'One Dark Pro': 'oneDarkPro',
    'Solarized Dark': 'solarizedDark',
  };

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.editorBg,
      padding: const EdgeInsets.all(12),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 2.5,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
        ),
        itemCount: EditorThemes.allThemes.length,
        itemBuilder: (ctx, i) {
          final theme = EditorThemes.allThemes[i];
          final key = _themeKeyForType(theme.type);
          final isSelected = settings.theme == key;
          return GestureDetector(
            onTap: () => settings.setTheme(key),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [theme.previewColor1, theme.previewColor2],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(
                  color: isSelected ? AppColors.activeTabBorder : const Color(0xFF3C3C3C),
                  width: isSelected ? 2 : 1,
                ),
              ),
              child: Stack(
                children: [
                  Center(
                    child: Text(
                      theme.name,
                      style: TextStyle(
                        color: theme.defaultText,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  if (isSelected)
                    const Positioned(
                      top: 4,
                      right: 4,
                      child: Icon(Icons.check_circle, color: AppColors.activeTabBorder, size: 14),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  String _themeKeyForType(EditorThemeType type) {
    switch (type) {
      case EditorThemeType.vsDarkPlus: return 'vsDarkPlus';
      case EditorThemeType.vsLight: return 'vsLight';
      case EditorThemeType.monokai: return 'monokai';
      case EditorThemeType.dracula: return 'dracula';
      case EditorThemeType.oneDarkPro: return 'oneDarkPro';
      case EditorThemeType.solarizedDark: return 'solarizedDark';
    }
  }
}

class _CompilerPickerRow extends StatelessWidget {
  final SettingsProvider settings;
  const _CompilerPickerRow({required this.settings});

  @override
  Widget build(BuildContext context) {
    return _DropdownRow(
      label: 'Default Compiler',
      value: settings.compiler,
      items: AppCompilers.compilers.map((c) => DropdownMenuItem<String>(
        value: c['value']!,
        child: Text(c['name']!, style: const TextStyle(color: AppColors.defaultText, fontSize: 13)),
      )).toList(),
      onChanged: settings.setCompiler,
    );
  }
}

class _StandardPickerRow extends StatelessWidget {
  final SettingsProvider settings;
  const _StandardPickerRow({required this.settings});

  @override
  Widget build(BuildContext context) {
    return _DropdownRow(
      label: 'Default Standard',
      value: settings.cppStandard,
      items: AppCompilers.standards.map((s) => DropdownMenuItem<String>(
        value: s['value']!,
        child: Text(s['name']!, style: const TextStyle(color: AppColors.defaultText, fontSize: 13)),
      )).toList(),
      onChanged: settings.setCppStandard,
    );
  }
}

class _DropdownRow extends StatelessWidget {
  final String label;
  final String value;
  final List<DropdownMenuItem<String>> items;
  final ValueChanged<String?> onChanged;

  const _DropdownRow({
    required this.label,
    required this.value,
    required this.items,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.editorBg,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: AppColors.defaultText, fontSize: 14)),
          DropdownButton<String>(
            value: value,
            items: items,
            onChanged: onChanged,
            dropdownColor: AppColors.sidebarBg,
            underline: const SizedBox.shrink(),
            icon: const Icon(Icons.expand_more, color: AppColors.dimText, size: 16),
            style: const TextStyle(color: AppColors.defaultText, fontSize: 13),
          ),
        ],
      ),
    );
  }
}

class _CompilerFlagsRow extends StatelessWidget {
  final SettingsProvider settings;
  const _CompilerFlagsRow({required this.settings});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.editorBg,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Extra Compiler Flags', style: TextStyle(color: AppColors.defaultText, fontSize: 14)),
          const SizedBox(height: 8),
          TextFormField(
            initialValue: settings.compilerFlags,
            style: const TextStyle(color: AppColors.defaultText, fontSize: 13, fontFamily: 'monospace'),
            decoration: const InputDecoration(
              hintText: 'Common: -Wall -Wextra -O2 -std=c++17',
              hintStyle: TextStyle(color: AppColors.dimText, fontSize: 12),
              filled: true,
              fillColor: AppColors.sidebarBg,
              border: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFF3C3C3C))),
              enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFF3C3C3C))),
              focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: AppColors.activeTabBorder)),
              contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            ),
            onChanged: settings.setCompilerFlags,
          ),
        ],
      ),
    );
  }
}

class _TimeoutRow extends StatelessWidget {
  final SettingsProvider settings;
  const _TimeoutRow({required this.settings});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.editorBg,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text('Run Timeout', style: TextStyle(color: AppColors.defaultText, fontSize: 14)),
          SegmentedButton<int>(
            segments: const [
              ButtonSegment(value: 10, label: Text('10s')),
              ButtonSegment(value: 30, label: Text('30s')),
              ButtonSegment(value: 60, label: Text('60s')),
            ],
            selected: {settings.timeout},
            onSelectionChanged: (s) => settings.setTimeout(s.first),
            style: ButtonStyle(
              backgroundColor: WidgetStateProperty.resolveWith(
                (states) => states.contains(WidgetState.selected)
                    ? AppColors.activeTabBorder.withOpacity(0.3)
                    : AppColors.tabBarBg,
              ),
              foregroundColor: WidgetStateProperty.all(AppColors.defaultText),
              side: WidgetStateProperty.all(const BorderSide(color: Color(0xFF3C3C3C))),
            ),
          ),
        ],
      ),
    );
  }
}

class _AboutRow extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;

  const _AboutRow({required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.editorBg,
      child: ListTile(
        leading: Icon(icon, color: AppColors.dimText, size: 18),
        title: Text(label, style: const TextStyle(color: AppColors.defaultText, fontSize: 14)),
        subtitle: Text(value, style: const TextStyle(color: AppColors.dimText, fontSize: 12)),
      ),
    );
  }
}
