import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../constants/app_constants.dart';
import '../constants/snippets_data.dart';
import '../providers/editor_provider.dart';

class SnippetsScreen extends StatefulWidget {
  const SnippetsScreen({super.key});

  @override
  State<SnippetsScreen> createState() => _SnippetsScreenState();
}

class _SnippetsScreenState extends State<SnippetsScreen> {
  String _selectedCategory = 'All';
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<CodeSnippet> get _filteredSnippets {
    var list = kCodeSnippets;
    if (_selectedCategory != 'All') {
      list = list.where((s) => s.category == _selectedCategory).toList();
    }
    if (_searchQuery.isNotEmpty) {
      final q = _searchQuery.toLowerCase();
      list = list
          .where((s) =>
              s.title.toLowerCase().contains(q) ||
              s.code.toLowerCase().contains(q) ||
              s.category.toLowerCase().contains(q))
          .toList();
    }
    return list;
  }

  @override
  Widget build(BuildContext context) {
    final snippets = _filteredSnippets;

    return Scaffold(
      backgroundColor: AppColors.editorBg,
      appBar: AppBar(
        backgroundColor: AppColors.gradientMid,
        title: const Text('Code Snippets', style: TextStyle(color: Colors.white, fontSize: 16)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(48),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
            child: TextField(
              controller: _searchController,
              style: const TextStyle(color: AppColors.defaultText),
              decoration: InputDecoration(
                hintText: 'Search snippets...',
                hintStyle: const TextStyle(color: AppColors.dimText),
                prefixIcon: const Icon(Icons.search, color: AppColors.dimText, size: 18),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear, color: AppColors.dimText, size: 16),
                        onPressed: () {
                          _searchController.clear();
                          setState(() => _searchQuery = '');
                        },
                      )
                    : null,
                filled: true,
                fillColor: AppColors.editorBg.withOpacity(0.5),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide.none,
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 12),
              ),
              onChanged: (v) => setState(() => _searchQuery = v),
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          _buildCategoryChips(),
          Expanded(
            child: snippets.isEmpty
                ? const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.search_off, color: AppColors.dimText, size: 48),
                        SizedBox(height: 12),
                        Text('No snippets found', style: TextStyle(color: AppColors.dimText)),
                      ],
                    ),
                  )
                : GridView.builder(
                    padding: const EdgeInsets.all(12),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 0.85,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                    ),
                    itemCount: snippets.length,
                    itemBuilder: (ctx, i) => _SnippetCard(
                      snippet: snippets[i],
                      onUse: () => _useSnippet(context, snippets[i]),
                    )
                        .animate(delay: Duration(milliseconds: i * 50))
                        .fadeIn(duration: 200.ms)
                        .slideY(begin: 0.2, duration: 200.ms),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryChips() {
    return Container(
      height: 44,
      color: AppColors.sidebarBg,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        children: kSnippetCategories.map((cat) {
          final isSelected = _selectedCategory == cat;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: FilterChip(
              label: Text(cat),
              selected: isSelected,
              onSelected: (_) => setState(() => _selectedCategory = cat),
              backgroundColor: AppColors.tabBarBg,
              selectedColor: AppColors.activeTabBorder.withOpacity(0.3),
              checkmarkColor: AppColors.activeTabBorder,
              labelStyle: TextStyle(
                color: isSelected ? AppColors.activeTabBorder : AppColors.dimText,
                fontSize: 12,
              ),
              side: BorderSide(
                color: isSelected ? AppColors.activeTabBorder : const Color(0xFF3C3C3C),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 4),
              visualDensity: VisualDensity.compact,
            ),
          );
        }).toList(),
      ),
    );
  }

  void _useSnippet(BuildContext context, CodeSnippet snippet) {
    final editor = context.read<EditorProvider>();
    editor.insertSnippet(snippet.code);
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Inserted: ${snippet.title}'),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}

class _SnippetCard extends StatelessWidget {
  final CodeSnippet snippet;
  final VoidCallback onUse;

  const _SnippetCard({required this.snippet, required this.onUse});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.sidebarBg,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFF3C3C3C)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: const BoxDecoration(
              color: AppColors.tabBarBg,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(8),
                topRight: Radius.circular(8),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    snippet.title,
                    style: const TextStyle(
                      color: AppColors.defaultText,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                  decoration: BoxDecoration(
                    color: AppColors.activeTabBorder.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(3),
                  ),
                  child: Text(
                    snippet.category,
                    style: const TextStyle(color: AppColors.activeTabBorder, fontSize: 9),
                  ),
                ),
              ],
            ),
          ),
          // Code preview
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Text(
                snippet.preview,
                style: const TextStyle(
                  color: AppColors.dimText,
                  fontSize: 10,
                  fontFamily: 'monospace',
                  height: 1.4,
                ),
                overflow: TextOverflow.fade,
              ),
            ),
          ),
          // Divider
          const Divider(height: 1, color: Color(0xFF3C3C3C)),
          // Use button
          SizedBox(
            width: double.infinity,
            child: TextButton(
              onPressed: onUse,
              style: TextButton.styleFrom(
                backgroundColor: AppColors.syntaxType.withOpacity(0.15),
                foregroundColor: AppColors.syntaxType,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(8),
                    bottomRight: Radius.circular(8),
                  ),
                ),
                padding: const EdgeInsets.symmetric(vertical: 8),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.add_circle_outline, size: 14),
                  SizedBox(width: 4),
                  Text('Use in Editor', style: TextStyle(fontSize: 11)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
