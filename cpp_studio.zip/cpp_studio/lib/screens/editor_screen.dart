import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../constants/app_constants.dart';
import '../providers/editor_provider.dart';
import '../providers/settings_provider.dart';
import '../services/storage_service.dart';
import '../widgets/code_editor_widget.dart';
import '../widgets/error_panel_widget.dart';
import '../widgets/find_replace_widget.dart';
import '../widgets/input_panel_widget.dart';
import '../widgets/output_console_widget.dart';
import '../widgets/status_bar_widget.dart';
import '../widgets/top_toolbar_widget.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  double _bottomPanelHeight = AppSizes.defaultBottomPanelHeight;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  bool _atMaxTabs = false;

  @override
  void initState() {
    super.initState();
    _loadPanelHeight();
  }

  Future<void> _loadPanelHeight() async {
    final h = await StorageService.loadBottomPanelHeight();
    if (mounted) setState(() => _bottomPanelHeight = h);
  }

  Future<void> _openFile() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['cpp', 'cc', 'cxx', 'h', 'hpp', 'c', 'txt'],
        withData: true,
      );
      if (!mounted || result == null) return;
      final file = result.files.first;
      String? content;
      if (file.bytes != null) {
        content = String.fromCharCodes(file.bytes!);
      } else if (file.path != null) {
        content = await File(file.path!).readAsString();
      }
      if (content == null) return;
      if (!mounted) return;
      context.read<EditorProvider>().openFileFromDisk(
            file.path ?? '',
            content,
            file.name,
          );
    } catch (_) {}
  }

  Future<void> _shareCurrentFile() async {
    final editor = context.read<EditorProvider>();
    final file = editor.activeFile;
    if (file == null) return;
    await Share.share(file.content, subject: file.name);
  }

  Future<bool> _confirmClose(String fileName) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.sidebarBg,
        title: const Text('Unsaved Changes', style: TextStyle(color: AppColors.defaultText)),
        content: Text(
          'Save changes to $fileName?',
          style: const TextStyle(color: AppColors.dimText),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Discard', style: TextStyle(color: AppColors.dimText)),
          ),
          TextButton(
            onPressed: () {
              context.read<EditorProvider>().saveCurrentFile();
              Navigator.pop(ctx, true);
            },
            child: const Text('Save', style: TextStyle(color: AppColors.activeTabBorder)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, null),
            child: const Text('Cancel', style: TextStyle(color: AppColors.dimText)),
          ),
        ],
      ),
    );
    return result != null;
  }

  void _showTabContextMenu(BuildContext context, int index, EditorProvider editor) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.sidebarBg,
      builder: (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.close, color: AppColors.defaultText),
            title: const Text('Close', style: TextStyle(color: AppColors.defaultText)),
            onTap: () {
              Navigator.pop(ctx);
              _handleCloseTab(index, editor);
            },
          ),
          ListTile(
            leading: const Icon(Icons.close_fullscreen, color: AppColors.defaultText),
            title: const Text('Close Others', style: TextStyle(color: AppColors.defaultText)),
            onTap: () {
              Navigator.pop(ctx);
              _closeOthers(index, editor);
            },
          ),
          ListTile(
            leading: const Icon(Icons.clear_all, color: AppColors.defaultText),
            title: const Text('Close All', style: TextStyle(color: AppColors.defaultText)),
            onTap: () {
              Navigator.pop(ctx);
              _closeAll(editor);
            },
          ),
        ],
      ),
    );
  }

  Future<void> _handleCloseTab(int index, EditorProvider editor) async {
    final file = editor.files[index];
    if (file.hasUnsavedChanges) {
      final proceed = await _confirmClose(file.name);
      if (!proceed) return;
    }
    editor.closeFile(index);
  }

  void _closeOthers(int keepIndex, EditorProvider editor) {
    final toClose = <int>[];
    for (int i = editor.files.length - 1; i >= 0; i--) {
      if (i != keepIndex) toClose.add(i);
    }
    for (final i in toClose) {
      editor.closeFile(i);
    }
  }

  void _closeAll(EditorProvider editor) {
    while (editor.files.length > 1) {
      editor.closeFile(editor.files.length - 1);
    }
    editor.closeFile(0);
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final keyboardVisible = mediaQuery.viewInsets.bottom > 50;
    final screenHeight = mediaQuery.size.height;
    final maxPanelH = screenHeight * AppSizes.maxBottomPanelHeightRatio;

    return Consumer<EditorProvider>(
      builder: (context, editor, _) {
        // Show max tabs snackbar
        if (_atMaxTabs != (editor.files.length >= AppSizes.maxTabs)) {
          _atMaxTabs = editor.files.length >= AppSizes.maxTabs;
        }

        return Scaffold(
          key: _scaffoldKey,
          backgroundColor: AppColors.editorBg,
          resizeToAvoidBottomInset: false,
          drawer: _buildDrawer(context, editor),
          body: SafeArea(
            child: Column(
              children: [
                TopToolbarWidget(
                  onMenuPressed: () => _scaffoldKey.currentState?.openDrawer(),
                ).animate().fadeIn(duration: 300.ms).slideY(begin: -0.3, duration: 300.ms),
                _buildTabBar(context, editor),
                Expanded(
                  child: Stack(
                    children: [
                      Column(
                        children: [
                          const Expanded(child: CodeEditorWidget()),
                          if (!keyboardVisible)
                            _buildResizeHandle(maxPanelH),
                          if (!keyboardVisible)
                            Container(
                              height: _bottomPanelHeight,
                              color: AppColors.sidebarBg,
                              child: _BottomPanelContent(
                                editor: editor,
                                onTabChanged: editor.setActiveBottomTab,
                              ),
                            ),
                        ],
                      ),
                      const FindReplaceWidget(),
                    ],
                  ),
                ).animate().slideY(begin: 0.3, end: 0, duration: 300.ms).fadeIn(duration: 300.ms),
                const StatusBarWidget(),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildTabBar(BuildContext context, EditorProvider editor) {
    return Container(
      height: AppSizes.tabBarHeight,
      color: AppColors.tabBarBg,
      child: Row(
        children: [
          Expanded(
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: editor.files.length,
              itemBuilder: (ctx, i) {
                final file = editor.files[i];
                final isActive = i == editor.activeFileIndex;
                return GestureDetector(
                  onLongPress: () => _showTabContextMenu(context, i, editor),
                  child: _TabItem(
                    file: file,
                    isActive: isActive,
                    onTap: () => editor.switchToFile(i),
                    onClose: () => _handleCloseTab(i, editor),
                  ),
                );
              },
            ),
          ),
          InkWell(
            onTap: () {
              if (editor.files.length >= AppSizes.maxTabs) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text(AppStrings.maxTabsError)),
                );
                return;
              }
              editor.createNewFile();
            },
            child: Container(
              width: 36,
              height: AppSizes.tabBarHeight,
              alignment: Alignment.center,
              color: AppColors.tabBarBg,
              child: const Icon(Icons.add, color: AppColors.dimText, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResizeHandle(double maxPanelHeight) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onVerticalDragUpdate: (details) {
        setState(() {
          _bottomPanelHeight =
              (_bottomPanelHeight - details.delta.dy).clamp(
            AppSizes.minBottomPanelHeight,
            maxPanelHeight,
          );
        });
      },
      onVerticalDragEnd: (_) {
        StorageService.saveBottomPanelHeight(_bottomPanelHeight);
      },
      child: Container(
        height: AppSizes.resizeHandleHeight,
        color: AppColors.tabBarBg,
        child: Center(
          child: Container(
            width: 40,
            height: 3,
            decoration: BoxDecoration(
              color: AppColors.dimText.withOpacity(0.5),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDrawer(BuildContext context, EditorProvider editor) {
    return Drawer(
      width: AppSizes.drawerWidth,
      backgroundColor: AppColors.sidebarBg,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(16, 48, 16, 16),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [AppColors.gradientStart, AppColors.gradientMid],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.terminal, color: Colors.white, size: 32),
                const SizedBox(height: 8),
                const Text(
                  'C++ Studio',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'v${AppStrings.appVersion} • Powered by Wandbox',
                  style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 11),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                _DrawerSection(title: '📁 FILES', children: [
                  _DrawerItem(
                    icon: Icons.add_box_outlined,
                    label: 'New File',
                    onTap: () {
                      Navigator.pop(context);
                      if (editor.files.length >= AppSizes.maxTabs) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text(AppStrings.maxTabsError)),
                        );
                      } else {
                        editor.createNewFile();
                      }
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.folder_open_outlined,
                    label: 'Open File...',
                    onTap: () {
                      Navigator.pop(context);
                      _openFile();
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.share_outlined,
                    label: 'Share Current File',
                    onTap: () {
                      Navigator.pop(context);
                      _shareCurrentFile();
                    },
                  ),
                ]),
                _DrawerSection(title: '📦 CODE SNIPPETS', children: [
                  _DrawerItem(
                    icon: Icons.code,
                    label: 'Browse Snippets Library',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/snippets');
                    },
                  ),
                ]),
                _DrawerSection(title: '⚙️ SETTINGS', children: [
                  _DrawerItem(
                    icon: Icons.settings_outlined,
                    label: 'Editor Settings',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/settings');
                    },
                  ),
                ]),
                _DrawerSection(title: 'ℹ️ ABOUT', children: [
                  _DrawerItem(
                    icon: Icons.info_outline,
                    label: 'App Version ${AppStrings.appVersion}',
                    onTap: () {},
                  ),
                  _DrawerItem(
                    icon: Icons.open_in_new,
                    label: 'Wandbox API (free)',
                    onTap: () {},
                  ),
                ]),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TabItem extends StatelessWidget {
  final dynamic file;
  final bool isActive;
  final VoidCallback onTap;
  final VoidCallback onClose;

  const _TabItem({
    required this.file,
    required this.isActive,
    required this.onTap,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        constraints: const BoxConstraints(
          minWidth: AppSizes.tabMinWidth,
          maxWidth: AppSizes.tabMaxWidth,
        ),
        decoration: BoxDecoration(
          color: isActive ? AppColors.activeTabBg : AppColors.inactiveTabBg,
          border: isActive
              ? const Border(top: BorderSide(color: AppColors.activeTabBorder, width: 2))
              : null,
        ),
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (file.hasUnsavedChanges)
              const Padding(
                padding: EdgeInsets.only(right: 4),
                child: Text('●', style: TextStyle(color: AppColors.unsavedDot, fontSize: 10)),
              ),
            Flexible(
              child: Text(
                file.name as String,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: isActive ? AppColors.defaultText : AppColors.dimText,
                  fontSize: 12,
                ),
              ),
            ),
            const SizedBox(width: 4),
            GestureDetector(
              onTap: onClose,
              child: Icon(
                Icons.close,
                size: 14,
                color: isActive ? AppColors.defaultText : AppColors.dimText,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BottomPanelContent extends StatelessWidget {
  final EditorProvider editor;
  final ValueChanged<int> onTabChanged;

  const _BottomPanelContent({required this.editor, required this.onTabChanged});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildPanelTabBar(),
        Expanded(child: _buildPanelContent()),
      ],
    );
  }

  Widget _buildPanelTabBar() {
    return Container(
      height: AppSizes.tabBarHeight,
      color: AppColors.tabBarBg,
      child: Row(
        children: [
          _PanelTab(label: 'INPUT', index: 0, active: editor.activeBottomTab == 0, onTap: onTabChanged),
          _PanelTab(
            label: 'OUTPUT',
            index: 1,
            active: editor.activeBottomTab == 1,
            onTap: onTabChanged,
            badge: editor.lastResult != null ? '●' : null,
            badgeColor: (editor.lastResult?.success == true) ? AppColors.successColor : AppColors.errorColor,
          ),
          _PanelTab(
            label: 'PROBLEMS',
            index: 2,
            active: editor.activeBottomTab == 2,
            onTap: onTabChanged,
            badge: editor.errorCount > 0 ? editor.errorCount.toString() : null,
            badgeColor: AppColors.errorColor,
          ),
        ],
      ),
    );
  }

  Widget _buildPanelContent() {
    switch (editor.activeBottomTab) {
      case 0:
        return InputPanelWidget(
          input: editor.stdinInput,
          onChanged: editor.setStdinInput,
          onClear: editor.clearStdin,
        );
      case 1:
        return OutputConsoleWidget(result: editor.lastResult, state: editor.compilationState);
      case 2:
        return ErrorPanelWidget(
          errors: editor.errors,
          onErrorTap: (line) => editor.jumpToLine(line),
        );
      default:
        return const SizedBox.shrink();
    }
  }
}

class _PanelTab extends StatelessWidget {
  final String label;
  final int index;
  final bool active;
  final ValueChanged<int> onTap;
  final String? badge;
  final Color? badgeColor;

  const _PanelTab({
    required this.label,
    required this.index,
    required this.active,
    required this.onTap,
    this.badge,
    this.badgeColor,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onTap(index),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        decoration: BoxDecoration(
          border: active
              ? const Border(top: BorderSide(color: AppColors.activeTabBorder, width: 2))
              : null,
          color: active ? AppColors.sidebarBg : Colors.transparent,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              label,
              style: TextStyle(
                color: active ? AppColors.defaultText : AppColors.dimText,
                fontSize: 11,
                fontWeight: active ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
            if (badge != null) ...[
              const SizedBox(width: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                decoration: BoxDecoration(
                  color: badgeColor ?? AppColors.errorColor,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  badge!,
                  style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _DrawerSection extends StatelessWidget {
  final String title;
  final List<Widget> children;
  const _DrawerSection({required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
          child: Text(title, style: const TextStyle(color: AppColors.dimText, fontSize: 11, fontWeight: FontWeight.w600)),
        ),
        ...children,
        const Divider(color: Color(0xFF3C3C3C), height: 1),
      ],
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _DrawerItem({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      dense: true,
      leading: Icon(icon, color: AppColors.dimText, size: 18),
      title: Text(label, style: const TextStyle(color: AppColors.defaultText, fontSize: 13)),
      onTap: onTap,
      hoverColor: Colors.white10,
    );
  }
}
