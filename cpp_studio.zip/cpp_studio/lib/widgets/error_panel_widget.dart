import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../constants/app_constants.dart';
import '../models/compiler_error.dart';

class ErrorPanelWidget extends StatelessWidget {
  final List<CompilerError> errors;
  final ValueChanged<int> onErrorTap;

  const ErrorPanelWidget({
    super.key,
    required this.errors,
    required this.onErrorTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.editorBg,
      child: Column(
        children: [
          _buildHeader(),
          Expanded(child: _buildBody(context)),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    final errorCount = errors.where((e) => e.isError).length;
    final warnCount = errors.where((e) => e.isWarning).length;

    return Container(
      height: 28,
      color: AppColors.sidebarBg,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        children: [
          if (errorCount > 0) ...[
            const Icon(Icons.error_outline, size: 12, color: AppColors.errorColor),
            const SizedBox(width: 4),
            Text('$errorCount error${errorCount == 1 ? '' : 's'}',
                style: const TextStyle(color: AppColors.errorColor, fontSize: 11)),
            const SizedBox(width: 10),
          ],
          if (warnCount > 0) ...[
            const Icon(Icons.warning_amber_outlined, size: 12, color: AppColors.warningColor),
            const SizedBox(width: 4),
            Text('$warnCount warning${warnCount == 1 ? '' : 's'}',
                style: const TextStyle(color: AppColors.warningColor, fontSize: 11)),
          ],
          if (errors.isEmpty)
            const Text('PROBLEMS', style: TextStyle(color: AppColors.dimText, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _buildBody(BuildContext context) {
    if (errors.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.check_circle_outline, color: AppColors.successColor, size: 32),
            SizedBox(height: 8),
            Text('✓  No problems detected',
                style: TextStyle(color: AppColors.successColor, fontSize: 13)),
          ],
        ),
      );
    }

    return ListView.builder(
      itemCount: errors.length,
      itemBuilder: (ctx, i) => _ErrorItem(
        error: errors[i],
        onTap: () => onErrorTap(errors[i].line),
        onLongPress: () => _copyError(ctx, errors[i]),
      )
          .animate(delay: Duration(milliseconds: i * 50))
          .fadeIn(duration: 150.ms),
    );
  }

  void _copyError(BuildContext context, CompilerError error) {
    Clipboard.setData(ClipboardData(text: error.toString()));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Error message copied'),
        duration: Duration(seconds: 2),
      ),
    );
  }
}

class _ErrorItem extends StatelessWidget {
  final CompilerError error;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  const _ErrorItem({
    required this.error,
    required this.onTap,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final isError = error.isError;
    final isWarning = error.isWarning;

    final iconColor = isError
        ? AppColors.errorColor
        : isWarning
            ? AppColors.warningColor
            : AppColors.dimText;

    final icon = isError
        ? Icons.cancel
        : isWarning
            ? Icons.warning_amber_rounded
            : Icons.info_outline;

    return InkWell(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          border: Border(
            left: BorderSide(color: iconColor, width: 3),
            bottom: const BorderSide(color: Color(0xFF2D2D2D), width: 1),
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: iconColor, size: 14),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        error.file,
                        style: const TextStyle(
                          color: AppColors.defaultText,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'line ${error.line}, col ${error.column}',
                        style: const TextStyle(color: AppColors.dimText, fontSize: 11),
                      ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    error.message,
                    style: TextStyle(
                      color: iconColor.withOpacity(0.85),
                      fontSize: 11,
                      fontFamily: 'monospace',
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: AppColors.dimText, size: 14),
          ],
        ),
      ),
    );
  }
}
