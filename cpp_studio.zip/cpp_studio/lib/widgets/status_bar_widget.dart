import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../constants/app_constants.dart';
import '../providers/editor_provider.dart';
import '../providers/settings_provider.dart';

class StatusBarWidget extends StatelessWidget {
  const StatusBarWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer2<EditorProvider, SettingsProvider>(
      builder: (context, editor, settings, _) {
        final compiler = AppCompilers.getCompilerDisplay(settings.compiler);
        final standard = settings.cppStandard.toUpperCase().replaceAll('++', '++');

        return Container(
          height: AppSizes.statusBarHeight,
          color: settings.editorTheme.statusBarBg,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: Row(
            children: [
              // Compiler
              _StatusItem(
                text: '⚡ $compiler',
                onTap: () => _showCompilerPicker(context, settings),
              ),
              const _Separator(),
              // Standard
              _StatusItem(
                text: standard.toUpperCase(),
                onTap: () => _showStandardPicker(context, settings),
              ),
              const _Separator(),
              // Cursor
              _StatusItem(
                text: 'Ln ${editor.cursorLine}, Col ${editor.cursorColumn}',
              ),
              const _Separator(),
              // Encoding
              const _StatusItem(text: AppStrings.defaultEncoding),
              const Spacer(),
              // Compilation status indicator
              if (editor.compilationState == CompilationState.compiling)
                const SizedBox(
                  width: 10,
                  height: 10,
                  child: CircularProgressIndicator(
                    strokeWidth: 1.5,
                    color: Colors.white,
                  ),
                )
              else if (editor.compilationState == CompilationState.success)
                const Icon(Icons.check_circle, color: AppColors.runBtnColor, size: 12)
              else if (editor.compilationState == CompilationState.error ||
                  editor.compilationState == CompilationState.networkError)
                const Icon(Icons.error_outline, color: AppColors.errorColor, size: 12),
            ],
          ),
        );
      },
    );
  }

  void _showCompilerPicker(BuildContext context, SettingsProvider settings) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.sidebarBg,
      builder: (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('Select Compiler',
                style: TextStyle(color: AppColors.defaultText, fontSize: 14, fontWeight: FontWeight.w600)),
          ),
          ...AppCompilers.compilers.map((c) => ListTile(
                title: Text(c['name']!, style: const TextStyle(color: AppColors.defaultText, fontSize: 13)),
                trailing: settings.compiler == c['value']
                    ? const Icon(Icons.check, color: AppColors.activeTabBorder)
                    : null,
                onTap: () {
                  settings.setCompiler(c['value']!);
                  Navigator.pop(ctx);
                },
              )),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  void _showStandardPicker(BuildContext context, SettingsProvider settings) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.sidebarBg,
      builder: (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('Select C++ Standard',
                style: TextStyle(color: AppColors.defaultText, fontSize: 14, fontWeight: FontWeight.w600)),
          ),
          ...AppCompilers.standards.map((s) => ListTile(
                title: Text(s['name']!, style: const TextStyle(color: AppColors.defaultText, fontSize: 13)),
                trailing: settings.cppStandard == s['value']
                    ? const Icon(Icons.check, color: AppColors.activeTabBorder)
                    : null,
                onTap: () {
                  settings.setCppStandard(s['value']!);
                  Navigator.pop(ctx);
                },
              )),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}

class _StatusItem extends StatelessWidget {
  final String text;
  final VoidCallback? onTap;

  const _StatusItem({required this.text, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: Text(
          text,
          style: const TextStyle(
            color: AppColors.statusBarText,
            fontSize: 10,
            fontFamily: 'monospace',
          ),
        ),
      ),
    );
  }
}

class _Separator extends StatelessWidget {
  const _Separator();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.symmetric(horizontal: 2),
      child: Text(' | ', style: TextStyle(color: Colors.white38, fontSize: 10)),
    );
  }
}
