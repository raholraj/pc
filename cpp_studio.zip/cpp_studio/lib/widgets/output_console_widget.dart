import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../constants/app_constants.dart';
import '../models/compilation_result.dart';
import '../providers/editor_provider.dart';

class OutputConsoleWidget extends StatelessWidget {
  final CompilationResult? result;
  final CompilationState state;

  const OutputConsoleWidget({
    super.key,
    required this.result,
    required this.state,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.editorBg,
      child: Column(
        children: [
          _buildHeader(context),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      height: 32,
      color: AppColors.sidebarBg,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        children: [
          const Icon(Icons.terminal, color: AppColors.dimText, size: 14),
          const SizedBox(width: 6),
          const Text('Output', style: TextStyle(color: AppColors.dimText, fontSize: 11)),
          const Spacer(),
          if (result != null) ...[
            _ActionButton(
              label: 'Copy',
              icon: Icons.copy,
              onTap: () {
                final text = _buildCopyText(result!);
                Clipboard.setData(ClipboardData(text: text));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Output copied to clipboard'),
                    duration: Duration(seconds: 2),
                  ),
                );
              },
            ),
            const SizedBox(width: 8),
            _ActionButton(
              label: 'Clear',
              icon: Icons.clear,
              onTap: () {},
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (state == CompilationState.compiling) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              color: AppColors.runBtnColor,
              strokeWidth: 2,
            ),
            SizedBox(height: 12),
            Text('Compiling...', style: TextStyle(color: AppColors.dimText, fontSize: 12)),
          ],
        ),
      );
    }

    if (result == null) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.play_circle_outline, color: AppColors.dimText, size: 40),
            SizedBox(height: 8),
            Text(
              'Press ▶ RUN to compile and execute',
              style: TextStyle(color: AppColors.dimText, fontSize: 12),
            ),
          ],
        ),
      );
    }

    if (result!.isNetworkError) {
      return _NetworkErrorView(message: result!.errorMessage!);
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildStatusHeader(),
          const SizedBox(height: 8),
          if (result!.compilationFailed) ...[
            _buildCompilerErrors(),
          ] else ...[
            if (result!.compilerMessage.isNotEmpty) ...[
              _buildWarningsSection(),
              const SizedBox(height: 8),
            ],
            if (result!.programOutput.isNotEmpty || result!.programError.isNotEmpty)
              _buildProgramOutput(),
            const SizedBox(height: 8),
            _buildExitCodeRow(),
          ],
        ],
      ),
    ).animate().fadeIn(duration: 200.ms).slideY(begin: 0.1, duration: 200.ms);
  }

  Widget _buildStatusHeader() {
    final isSuccess = result!.success;
    final isCompileFail = result!.compilationFailed;
    final color = isSuccess ? AppColors.successColor : AppColors.errorColor;
    final icon = isSuccess ? Icons.check_circle_outline : Icons.error_outline;
    final time = result!.compilationTime.inMilliseconds / 1000.0;
    final label = isCompileFail
        ? 'Compilation Failed (${time.toStringAsFixed(2)}s)'
        : 'Compiled in ${time.toStringAsFixed(2)}s — ${result!.compilerDisplayName}';

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              label,
              style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCompilerErrors() {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.errorColor.withOpacity(0.05),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: AppColors.errorColor.withOpacity(0.3)),
      ),
      child: SelectableText(
        result!.compilerMessage,
        style: const TextStyle(
          color: AppColors.errorColor,
          fontSize: 12,
          fontFamily: 'monospace',
          height: 1.5,
        ),
      ),
    );
  }

  Widget _buildWarningsSection() {
    final warnings = result!.compilerMessage
        .split('\n')
        .where((l) => l.contains('warning:'))
        .join('\n');
    if (warnings.isEmpty) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.warningColor.withOpacity(0.05),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: AppColors.warningColor.withOpacity(0.3)),
      ),
      child: SelectableText(
        warnings,
        style: const TextStyle(
          color: AppColors.warningColor,
          fontSize: 12,
          fontFamily: 'monospace',
          height: 1.5,
        ),
      ),
    );
  }

  Widget _buildProgramOutput() {
    final hasStdout = result!.programOutput.isNotEmpty;
    final hasStderr = result!.programError.isNotEmpty;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Divider(color: Color(0xFF3C3C3C)),
        if (hasStdout)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A1A),
              borderRadius: BorderRadius.circular(4),
            ),
            child: SelectableText(
              result!.programOutput,
              style: const TextStyle(
                color: AppColors.defaultText,
                fontSize: 12,
                fontFamily: 'monospace',
                height: 1.5,
              ),
            ),
          ),
        if (hasStderr) ...[
          if (hasStdout) const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.errorColor.withOpacity(0.05),
              borderRadius: BorderRadius.circular(4),
            ),
            child: SelectableText(
              result!.programError,
              style: const TextStyle(
                color: AppColors.errorColor,
                fontSize: 12,
                fontFamily: 'monospace',
                height: 1.5,
              ),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildExitCodeRow() {
    final isSuccess = result!.exitCode == 0 && !result!.compilationFailed;
    final hasCrash = result!.hasCrash;
    final color = isSuccess ? AppColors.successColor : AppColors.errorColor;
    final icon = isSuccess ? Icons.check : Icons.close;
    String label;
    if (hasCrash) {
      label = 'Exit Code: ${result!.exitCode}  ✕  Crash: ${result!.signal}';
    } else if (isSuccess) {
      label = 'Exit Code: 0  ✓  Success';
    } else {
      label = 'Exit Code: ${result!.exitCode}  ✕  Runtime Error';
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 14),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(color: color, fontSize: 11, fontFamily: 'monospace')),
        ],
      ),
    );
  }

  String _buildCopyText(CompilationResult r) {
    final buf = StringBuffer();
    buf.writeln('=== Compilation ===');
    buf.writeln('Compiler: ${r.compilerDisplayName}  Standard: ${r.standard}');
    buf.writeln('Time: ${r.compilationTime.inMilliseconds}ms  Exit: ${r.exitCode}');
    if (r.compilerMessage.isNotEmpty) {
      buf.writeln('\n=== Compiler Output ===');
      buf.write(r.compilerMessage);
    }
    if (r.programOutput.isNotEmpty) {
      buf.writeln('\n=== Program Output ===');
      buf.write(r.programOutput);
    }
    if (r.programError.isNotEmpty) {
      buf.writeln('\n=== Program Error ===');
      buf.write(r.programError);
    }
    return buf.toString();
  }
}

class _NetworkErrorView extends StatelessWidget {
  final String message;
  const _NetworkErrorView({required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.wifi_off, color: AppColors.errorColor, size: 40),
            const SizedBox(height: 12),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.errorColor, fontSize: 13),
            ),
            const SizedBox(height: 8),
            const Text(
              'Check your internet connection and try again.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.dimText, fontSize: 11),
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  const _ActionButton({required this.label, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(4),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 12, color: AppColors.dimText),
            const SizedBox(width: 3),
            Text(label, style: const TextStyle(color: AppColors.dimText, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}
