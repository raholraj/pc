import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../constants/app_constants.dart';
import '../providers/editor_provider.dart';
import '../providers/settings_provider.dart';

class TopToolbarWidget extends StatefulWidget {
  final VoidCallback onMenuPressed;

  const TopToolbarWidget({super.key, required this.onMenuPressed});

  @override
  State<TopToolbarWidget> createState() => _TopToolbarWidgetState();
}

class _TopToolbarWidgetState extends State<TopToolbarWidget> {
  bool _isEditingName = false;
  late TextEditingController _nameController;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController();
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer2<EditorProvider, SettingsProvider>(
      builder: (context, editor, settings, _) {
        final file = editor.activeFile;
        final fileName = file?.name ?? AppStrings.defaultFileName;
        final hasUnsaved = file?.hasUnsavedChanges ?? false;

        return Container(
          height: AppSizes.topBarHeight,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [AppColors.gradientStart, AppColors.gradientMid, AppColors.gradientEnd],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
          ),
          child: Row(
            children: [
              // Menu button
              IconButton(
                icon: const Icon(Icons.menu, color: Colors.white),
                onPressed: widget.onMenuPressed,
                tooltip: 'Menu',
                iconSize: 22,
              ),
              // File name
              Expanded(
                child: _isEditingName
                    ? _buildNameEditor(context, editor, fileName)
                    : GestureDetector(
                        onDoubleTap: () {
                          _nameController.text = fileName;
                          setState(() => _isEditingName = true);
                        },
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              fileName,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            if (hasUnsaved) ...[
                              const SizedBox(width: 4),
                              const Text('●', style: TextStyle(color: AppColors.unsavedDot, fontSize: 10)),
                            ],
                          ],
                        ),
                      ),
              ),
              // Right-side buttons
              _ToolbarIconButton(
                icon: Icons.undo,
                tooltip: 'Undo',
                enabled: editor.canUndo,
                onPressed: () {
                  if (editor.canUndo) {
                    editor.undo();
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text(AppStrings.nothingToUndo),
                        duration: Duration(seconds: 1),
                      ),
                    );
                  }
                },
              ),
              _ToolbarIconButton(
                icon: Icons.redo,
                tooltip: 'Redo',
                enabled: editor.canRedo,
                onPressed: () {
                  if (editor.canRedo) {
                    editor.redo();
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text(AppStrings.nothingToRedo),
                        duration: Duration(seconds: 1),
                      ),
                    );
                  }
                },
              ),
              _ToolbarIconButton(
                icon: Icons.search,
                tooltip: 'Find & Replace',
                enabled: true,
                onPressed: () => editor.toggleFindReplace(),
              ),
              _ToolbarIconButton(
                icon: Icons.settings_outlined,
                tooltip: 'Settings',
                enabled: true,
                onPressed: () => Navigator.pushNamed(context, '/settings'),
              ),
              const SizedBox(width: 4),
              _RunButton(editor: editor),
              const SizedBox(width: 8),
            ],
          ),
        );
      },
    );
  }

  Widget _buildNameEditor(BuildContext context, EditorProvider editor, String currentName) {
    return TextField(
      controller: _nameController,
      autofocus: true,
      style: const TextStyle(color: Colors.white, fontSize: 13),
      cursorColor: Colors.white,
      decoration: const InputDecoration(
        border: InputBorder.none,
        contentPadding: EdgeInsets.zero,
      ),
      onSubmitted: (value) {
        if (value.isNotEmpty) {
          editor.renameFile(editor.activeFileIndex, value.trim());
        }
        setState(() => _isEditingName = false);
      },
      onTapOutside: (_) {
        setState(() => _isEditingName = false);
      },
    );
  }
}

class _ToolbarIconButton extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final bool enabled;
  final VoidCallback onPressed;

  const _ToolbarIconButton({
    required this.icon,
    required this.tooltip,
    required this.enabled,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: enabled ? 1.0 : 0.4,
      child: SizedBox(
        width: AppSizes.iconBtnSize,
        height: AppSizes.iconBtnSize,
        child: IconButton(
          icon: Icon(icon, color: Colors.white, size: 18),
          tooltip: tooltip,
          onPressed: enabled ? onPressed : null,
          splashRadius: 18,
        ),
      ),
    );
  }
}

class _RunButton extends StatefulWidget {
  final EditorProvider editor;

  const _RunButton({required this.editor});

  @override
  State<_RunButton> createState() => _RunButtonState();
}

class _RunButtonState extends State<_RunButton> with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = widget.editor.compilationState;
    final isCompiling = state == CompilationState.compiling;
    final isError = state == CompilationState.error ||
        state == CompilationState.networkError;

    Color btnColor;
    Widget btnChild;

    if (isCompiling) {
      btnColor = AppColors.activeTabBorder;
      btnChild = const SizedBox(
        width: 18,
        height: 18,
        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
      );
    } else if (isError) {
      btnColor = AppColors.stopBtnColor;
      btnChild = const Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.close, color: Colors.white, size: 14),
          SizedBox(width: 3),
          Text('ERR', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
        ],
      );
    } else {
      btnColor = AppColors.runBtnColor;
      btnChild = const Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.play_arrow, color: Colors.black87, size: 16),
          SizedBox(width: 2),
          Text('RUN', style: TextStyle(color: Colors.black87, fontSize: 12, fontWeight: FontWeight.w700)),
        ],
      );
    }

    return GestureDetector(
      onTap: isCompiling
          ? null
          : () {
              widget.editor.compile();
            },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: AppSizes.runBtnWidth,
        height: 32,
        decoration: BoxDecoration(
          color: btnColor,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: btnColor.withOpacity(0.4),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Center(child: btnChild),
      )
          .animate(target: isCompiling ? 1 : 0)
          .scaleXY(begin: 1, end: 0.97, duration: 100.ms, curve: Curves.easeInOut),
    );
  }
}
