import 'package:flutter/material.dart';
import '../constants/app_constants.dart';

class InputPanelWidget extends StatefulWidget {
  final String input;
  final ValueChanged<String> onChanged;
  final VoidCallback onClear;

  const InputPanelWidget({
    super.key,
    required this.input,
    required this.onChanged,
    required this.onClear,
  });

  @override
  State<InputPanelWidget> createState() => _InputPanelWidgetState();
}

class _InputPanelWidgetState extends State<InputPanelWidget> {
  late final TextEditingController _controller;
  late final FocusNode _focusNode;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.input);
    _focusNode = FocusNode();
  }

  @override
  void didUpdateWidget(InputPanelWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.input != widget.input && _controller.text != widget.input) {
      _controller.text = widget.input;
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final charCount = _controller.text.length;

    return Container(
      color: AppColors.editorBg,
      child: Column(
        children: [
          // Header
          Container(
            height: 28,
            color: AppColors.sidebarBg,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: const Row(
              children: [
                Icon(Icons.input, size: 12, color: AppColors.dimText),
                SizedBox(width: 6),
                Text(
                  'stdin — Program Input',
                  style: TextStyle(color: AppColors.dimText, fontSize: 11),
                ),
              ],
            ),
          ),
          // Text area
          Expanded(
            child: TextField(
              controller: _controller,
              focusNode: _focusNode,
              maxLines: null,
              expands: true,
              style: const TextStyle(
                color: AppColors.defaultText,
                fontSize: 13,
                fontFamily: 'monospace',
                height: 1.5,
              ),
              decoration: const InputDecoration(
                hintText: 'Enter input here... (one value per line for cin)',
                hintStyle: TextStyle(color: AppColors.dimText, fontSize: 12),
                border: InputBorder.none,
                contentPadding: EdgeInsets.all(12),
                fillColor: AppColors.editorBg,
                filled: true,
              ),
              cursorColor: AppColors.cursorColor,
              onChanged: widget.onChanged,
            ),
          ),
          // Footer
          Container(
            height: 28,
            color: AppColors.sidebarBg,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  '$charCount chars',
                  style: const TextStyle(color: AppColors.dimText, fontSize: 10),
                ),
                const SizedBox(width: 12),
                GestureDetector(
                  onTap: () {
                    _controller.clear();
                    widget.onClear();
                  },
                  child: const Text(
                    '[Clear]',
                    style: TextStyle(color: AppColors.activeTabBorder, fontSize: 11),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
