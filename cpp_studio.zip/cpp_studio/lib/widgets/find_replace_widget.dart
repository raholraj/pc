import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../constants/app_constants.dart';
import '../providers/editor_provider.dart';

class FindReplaceWidget extends StatefulWidget {
  const FindReplaceWidget({super.key});

  @override
  State<FindReplaceWidget> createState() => _FindReplaceWidgetState();
}

class _FindReplaceWidgetState extends State<FindReplaceWidget> {
  final TextEditingController _findController = TextEditingController();
  final TextEditingController _replaceController = TextEditingController();
  final FocusNode _findFocus = FocusNode();
  bool _showReplace = false;

  @override
  void dispose() {
    _findController.dispose();
    _replaceController.dispose();
    _findFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<EditorProvider>(
      builder: (context, editor, _) {
        if (!editor.showFindReplace) {
          return const SizedBox.shrink();
        }

        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (editor.showFindReplace) _findFocus.requestFocus();
        });

        return Positioned(
          top: 0,
          left: 0,
          right: 0,
          child: _buildPanel(context, editor)
              .animate()
              .slideY(begin: -1, end: 0, duration: 300.ms, curve: Curves.easeOut)
              .fadeIn(duration: 200.ms),
        );
      },
    );
  }

  Widget _buildPanel(BuildContext context, EditorProvider editor) {
    return Container(
      color: AppColors.sidebarBg,
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
      decoration: BoxDecoration(
        color: AppColors.sidebarBg,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Find row
          Row(
            children: [
              const Icon(Icons.search, color: AppColors.dimText, size: 16),
              const SizedBox(width: 6),
              Expanded(
                child: _buildTextField(
                  controller: _findController,
                  focusNode: _findFocus,
                  hint: 'Find',
                  onChanged: editor.setSearchQuery,
                ),
              ),
              const SizedBox(width: 6),
              // Match count
              if (editor.matchCount > 0)
                Text(
                  '${editor.currentMatchIndex + 1}/${editor.matchCount}',
                  style: const TextStyle(color: AppColors.dimText, fontSize: 11),
                )
              else if (_findController.text.isNotEmpty)
                const Text('No matches', style: TextStyle(color: AppColors.errorColor, fontSize: 11)),
              const SizedBox(width: 6),
              // Navigation
              _SmallIconBtn(
                icon: Icons.keyboard_arrow_up,
                onTap: editor.previousMatch,
                enabled: editor.matchCount > 0,
              ),
              _SmallIconBtn(
                icon: Icons.keyboard_arrow_down,
                onTap: editor.nextMatch,
                enabled: editor.matchCount > 0,
              ),
              // Toggle replace
              _SmallIconBtn(
                icon: _showReplace ? Icons.expand_less : Icons.expand_more,
                onTap: () => setState(() => _showReplace = !_showReplace),
                enabled: true,
              ),
              // Close
              _SmallIconBtn(
                icon: Icons.close,
                onTap: () {
                  _findController.clear();
                  _replaceController.clear();
                  editor.toggleFindReplace();
                },
                enabled: true,
              ),
            ],
          ),
          // Options row
          Padding(
            padding: const EdgeInsets.only(top: 4, left: 22),
            child: Row(
              children: [
                _OptionChip(
                  label: 'Aa',
                  tooltip: 'Case Sensitive',
                  active: editor.caseSensitive,
                  onTap: () => editor.setSearchOptions(caseSensitive: !editor.caseSensitive),
                ),
                const SizedBox(width: 4),
                _OptionChip(
                  label: 'W',
                  tooltip: 'Whole Word',
                  active: editor.wholeWord,
                  onTap: () => editor.setSearchOptions(wholeWord: !editor.wholeWord),
                ),
                const SizedBox(width: 4),
                _OptionChip(
                  label: '.*',
                  tooltip: 'Regular Expression',
                  active: editor.useRegex,
                  onTap: () => editor.setSearchOptions(useRegex: !editor.useRegex),
                ),
              ],
            ),
          ),
          // Replace row (collapsible)
          if (_showReplace) ...[
            const SizedBox(height: 6),
            Row(
              children: [
                const SizedBox(width: 22),
                const Icon(Icons.find_replace, color: AppColors.dimText, size: 14),
                const SizedBox(width: 6),
                Expanded(
                  child: _buildTextField(
                    controller: _replaceController,
                    hint: 'Replace',
                    onChanged: editor.setReplaceQuery,
                  ),
                ),
                const SizedBox(width: 6),
                _ReplaceButton(
                  label: 'Replace',
                  onTap: editor.replaceCurrent,
                  enabled: editor.matchCount > 0,
                ),
                const SizedBox(width: 4),
                _ReplaceButton(
                  label: 'All',
                  onTap: editor.replaceAll,
                  enabled: editor.matchCount > 0,
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    FocusNode? focusNode,
    required String hint,
    required ValueChanged<String> onChanged,
  }) {
    return TextField(
      controller: controller,
      focusNode: focusNode,
      style: const TextStyle(color: AppColors.defaultText, fontSize: 13),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: AppColors.dimText, fontSize: 12),
        filled: true,
        fillColor: AppColors.editorBg,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(4),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(4),
          borderSide: const BorderSide(color: AppColors.activeTabBorder, width: 1),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        isDense: true,
      ),
      onChanged: onChanged,
    );
  }
}

class _SmallIconBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool enabled;

  const _SmallIconBtn({required this.icon, required this.onTap, required this.enabled});

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: enabled ? 1.0 : 0.4,
      child: InkWell(
        onTap: enabled ? onTap : null,
        borderRadius: BorderRadius.circular(4),
        child: Padding(
          padding: const EdgeInsets.all(4),
          child: Icon(icon, color: AppColors.dimText, size: 16),
        ),
      ),
    );
  }
}

class _OptionChip extends StatelessWidget {
  final String label;
  final String tooltip;
  final bool active;
  final VoidCallback onTap;

  const _OptionChip({
    required this.label,
    required this.tooltip,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
          decoration: BoxDecoration(
            color: active ? AppColors.activeTabBorder.withOpacity(0.25) : Colors.transparent,
            borderRadius: BorderRadius.circular(4),
            border: Border.all(
              color: active ? AppColors.activeTabBorder : const Color(0xFF3C3C3C),
            ),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: active ? AppColors.activeTabBorder : AppColors.dimText,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }
}

class _ReplaceButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final bool enabled;

  const _ReplaceButton({required this.label, required this.onTap, required this.enabled});

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: enabled ? 1.0 : 0.4,
      child: InkWell(
        onTap: enabled ? onTap : null,
        borderRadius: BorderRadius.circular(4),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: const Color(0xFF3C3C3C),
            borderRadius: BorderRadius.circular(4),
          ),
          child: Text(
            label,
            style: const TextStyle(color: AppColors.defaultText, fontSize: 11),
          ),
        ),
      ),
    );
  }
}
