import 'package:flutter/material.dart';
import 'package:flutter_code_editor/flutter_code_editor.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../constants/app_constants.dart';
import '../providers/editor_provider.dart';
import '../providers/settings_provider.dart';

class CodeEditorWidget extends StatefulWidget {
  const CodeEditorWidget({super.key});

  @override
  State<CodeEditorWidget> createState() => _CodeEditorWidgetState();
}

class _CodeEditorWidgetState extends State<CodeEditorWidget> {
  final ScrollController _verticalScrollController = ScrollController();
  final ScrollController _horizontalScrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final editor = context.read<EditorProvider>();
      editor.setScrollController(_verticalScrollController);
    });
  }

  @override
  void dispose() {
    _verticalScrollController.dispose();
    _horizontalScrollController.dispose();
    super.dispose();
  }

  TextStyle _getCodeFont(SettingsProvider settings) {
    final size = settings.fontSize;
    switch (settings.fontFamily) {
      case 'Fira Code':
        return GoogleFonts.firaCode(fontSize: size, color: AppColors.defaultText, height: 1.5);
      case 'JetBrains Mono':
        return GoogleFonts.jetBrainsMono(fontSize: size, color: AppColors.defaultText, height: 1.5);
      default:
        return TextStyle(
          fontFamily: 'Courier New',
          fontSize: size,
          color: AppColors.defaultText,
          height: 1.5,
        );
    }
  }

  TextStyle _getGutterFont(SettingsProvider settings) {
    final size = settings.fontSize;
    switch (settings.fontFamily) {
      case 'Fira Code':
        return GoogleFonts.firaCode(fontSize: size, color: AppColors.dimText, height: 1.5);
      case 'JetBrains Mono':
        return GoogleFonts.jetBrainsMono(fontSize: size, color: AppColors.dimText, height: 1.5);
      default:
        return TextStyle(
          fontFamily: 'Courier New',
          fontSize: size,
          color: AppColors.dimText,
          height: 1.5,
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer2<EditorProvider, SettingsProvider>(
      builder: (context, editor, settings, _) {
        final controller = editor.activeController;
        final theme = settings.editorTheme;

        if (controller == null) {
          return Container(
            color: theme.background,
            child: const Center(
              child: Text('No file open', style: TextStyle(color: AppColors.dimText)),
            ),
          );
        }

        final codeFont = _getCodeFont(settings);
        final gutterFont = _getGutterFont(settings);

        return Container(
          color: theme.background,
          child: Stack(
            children: [
              // Error line highlights
              if (editor.errors.isNotEmpty)
                Positioned.fill(
                  child: _ErrorLineHighlights(
                    errors: editor.errors,
                    fontSize: settings.fontSize,
                    flashLine: editor.flashLine,
                    scrollController: _verticalScrollController,
                  ),
                ),
              // Code editor
              SingleChildScrollView(
                controller: _verticalScrollController,
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  controller: _horizontalScrollController,
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      minWidth: MediaQuery.of(context).size.width,
                    ),
                    child: CodeTheme(
                      data: CodeThemeData(styles: theme.syntaxStyles),
                      child: CodeField(
                        controller: controller,
                        textStyle: codeFont,
                        lineNumberStyle: LineNumberStyle(
                          width: AppSizes.gutterWidth,
                          margin: 8,
                          textAlign: TextAlign.right,
                          textStyle: gutterFont,
                          background: theme.lineNumberBg,
                        ),
                        background: theme.background,
                        cursorColor: theme.cursorColor,
                        textSelectionTheme: TextSelectionThemeData(
                          selectionColor: theme.selectionBg,
                          cursorColor: theme.cursorColor,
                        ),
                        wrap: settings.wordWrap,
                        minLines: null,
                        maxLines: null,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ErrorLineHighlights extends StatelessWidget {
  final List errors;
  final double fontSize;
  final int? flashLine;
  final ScrollController scrollController;

  const _ErrorLineHighlights({
    required this.errors,
    required this.fontSize,
    required this.flashLine,
    required this.scrollController,
  });

  @override
  Widget build(BuildContext context) {
    final lineHeight = fontSize * 1.5;

    return AnimatedBuilder(
      animation: scrollController,
      builder: (context, _) {
        final scrollOffset = scrollController.hasClients ? scrollController.offset : 0.0;
        final viewportHeight = scrollController.hasClients
            ? scrollController.position.viewportDimension
            : MediaQuery.of(context).size.height;

        return Stack(
          children: errors.map<Widget>((error) {
            final line = error.line as int;
            final isError = error.severity == 'error';
            final top = (line - 1) * lineHeight - scrollOffset;

            if (top < -lineHeight || top > viewportHeight) {
              return const SizedBox.shrink();
            }

            final isFlashing = flashLine == line;
            final borderColor = isError ? AppColors.errorColor : AppColors.warningColor;

            return Positioned(
              left: AppSizes.gutterWidth,
              top: top,
              right: 0,
              height: lineHeight,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                decoration: BoxDecoration(
                  color: isFlashing
                      ? AppColors.findCurrentBg.withOpacity(0.15)
                      : (isError
                          ? AppColors.errorColor.withOpacity(0.05)
                          : AppColors.warningColor.withOpacity(0.04)),
                  border: Border(
                    left: BorderSide(color: borderColor, width: 3),
                  ),
                ),
              ),
            );
          }).toList(),
        );
      },
    );
  }
}
