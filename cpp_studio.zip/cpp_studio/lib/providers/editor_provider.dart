import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_code_editor/flutter_code_editor.dart';
import 'package:highlight/languages/cpp.dart';
import '../constants/app_constants.dart';
import '../models/code_file.dart';
import '../models/compilation_result.dart';
import '../models/compiler_error.dart';
import '../providers/settings_provider.dart';
import '../services/compiler_service.dart';
import '../services/error_parser.dart';
import '../services/storage_service.dart';

enum CompilationState { idle, compiling, success, error, networkError }

class EditorProvider extends ChangeNotifier {
  // ─── Files & Tabs ─────────────────────────────────────────────────────
  final List<CodeFile> _files = [];
  int _activeFileIndex = 0;
  final Map<String, CodeController> _controllers = {};
  final Map<String, List<String>> _undoStacks = {};
  final Map<String, List<String>> _redoStacks = {};

  // ─── Compilation ──────────────────────────────────────────────────────
  CompilationState _compilationState = CompilationState.idle;
  CompilationResult? _lastResult;
  List<CompilerError> _errors = [];

  // ─── UI State ─────────────────────────────────────────────────────────
  int _activeBottomTab = 1; // 0=input, 1=output, 2=problems
  String _stdinInput = '';
  bool _showFindReplace = false;
  String _searchQuery = '';
  String _replaceQuery = '';
  bool _caseSensitive = false;
  bool _wholeWord = false;
  bool _useRegex = false;
  int _currentMatchIndex = 0;
  List<int> _matchPositions = [];
  int _cursorLine = 1;
  int _cursorColumn = 1;

  // ─── Scroll & Flash ───────────────────────────────────────────────────
  ScrollController? _editorScrollController;
  int? _flashLine;
  Timer? _flashTimer;

  // ─── Services ─────────────────────────────────────────────────────────
  final CompilerService _compilerService = CompilerService();
  Timer? _autoSaveTimer;
  SettingsProvider? _settings;

  EditorProvider() {
    _startAutoSave();
  }

  // ─── Getters ──────────────────────────────────────────────────────────
  List<CodeFile> get files => List.unmodifiable(_files);
  int get activeFileIndex => _activeFileIndex;
  CodeFile? get activeFile =>
      _files.isNotEmpty && _activeFileIndex < _files.length ? _files[_activeFileIndex] : null;
  CompilationState get compilationState => _compilationState;
  CompilationResult? get lastResult => _lastResult;
  List<CompilerError> get errors => List.unmodifiable(_errors);
  int get activeBottomTab => _activeBottomTab;
  String get stdinInput => _stdinInput;
  bool get showFindReplace => _showFindReplace;
  String get searchQuery => _searchQuery;
  String get replaceQuery => _replaceQuery;
  bool get caseSensitive => _caseSensitive;
  bool get wholeWord => _wholeWord;
  bool get useRegex => _useRegex;
  int get currentMatchIndex => _currentMatchIndex;
  List<int> get matchPositions => List.unmodifiable(_matchPositions);
  int get matchCount => _matchPositions.length;
  int get cursorLine => _cursorLine;
  int get cursorColumn => _cursorColumn;
  int? get flashLine => _flashLine;
  bool get isCompiling => _compilationState == CompilationState.compiling;
  int get errorCount => ErrorParser.countErrors(_errors);
  int get warningCount => ErrorParser.countWarnings(_errors);

  CodeController? get activeController {
    final file = activeFile;
    if (file == null) return null;
    return _controllers[file.id];
  }

  bool get canUndo {
    final file = activeFile;
    if (file == null) return false;
    return (_undoStacks[file.id]?.isNotEmpty ?? false);
  }

  bool get canRedo {
    final file = activeFile;
    if (file == null) return false;
    return (_redoStacks[file.id]?.isNotEmpty ?? false);
  }

  void setScrollController(ScrollController sc) {
    _editorScrollController = sc;
  }

  void updateSettings(SettingsProvider settings) {
    _settings = settings;
  }

  // ─── Session Restore ──────────────────────────────────────────────────
  Future<void> restoreSession() async {
    try {
      final session = await StorageService.loadSession();
      if (session != null) {
        final filesJson = session['openFiles'] as List<dynamic>? ?? [];
        final activeIdx = session['activeFileIndex'] as int? ?? 0;

        for (final fileJson in filesJson) {
          final file = CodeFile.fromJson(fileJson as Map<String, dynamic>);
          final savedContent = await StorageService.loadFileContent(file.id);
          if (savedContent != null) {
            file.content = savedContent;
          }
          _addFileInternal(file);
        }

        if (_files.isNotEmpty) {
          _activeFileIndex = activeIdx.clamp(0, _files.length - 1);
        }
      }
    } catch (_) {}

    if (_files.isEmpty) {
      createNewFile();
    }

    notifyListeners();
  }

  // ─── File Management ──────────────────────────────────────────────────
  void _addFileInternal(CodeFile file) {
    _files.add(file);
    final controller = CodeController(
      text: file.content,
      language: cpp,
    );
    controller.addListener(() => _onControllerChanged(file.id));
    _controllers[file.id] = controller;
    _undoStacks[file.id] = [];
    _redoStacks[file.id] = [];
  }

  void _onControllerChanged(String fileId) {
    final idx = _files.indexWhere((f) => f.id == fileId);
    if (idx < 0) return;
    final controller = _controllers[fileId];
    if (controller == null) return;

    final newText = controller.text;
    final file = _files[idx];

    if (newText != file.content) {
      // Save snapshot for undo (debounced)
      _saveUndoSnapshot(fileId, file.content);

      _files[idx] = file.copyWith(
        content: newText,
        hasUnsavedChanges: true,
        lastModified: DateTime.now(),
      );

      _updateCursorPosition(controller);
      notifyListeners();
    }
  }

  void _saveUndoSnapshot(String fileId, String previousText) {
    final stack = _undoStacks[fileId] ?? [];
    if (stack.isNotEmpty && stack.last == previousText) return;
    stack.add(previousText);
    if (stack.length > 100) stack.removeAt(0);
    _undoStacks[fileId] = stack;
    _redoStacks[fileId] = [];
  }

  void _updateCursorPosition(CodeController controller) {
    try {
      final text = controller.text;
      final offset = controller.selection.baseOffset;
      if (offset < 0 || offset > text.length) return;

      final before = text.substring(0, offset);
      final lines = before.split('\n');
      _cursorLine = lines.length;
      _cursorColumn = lines.last.length + 1;
    } catch (_) {}
  }

  void createNewFile({String? name, String? content}) {
    if (_files.length >= AppSizes.maxTabs) {
      // Will show snackbar via listener pattern
      notifyListeners();
      return;
    }

    final id = generateFileId();
    final fileName = name ?? _generateFileName();
    final fileContent = content ?? kDefaultCppTemplate;

    final file = CodeFile.newFile(id: id, name: fileName, content: fileContent);
    _addFileInternal(file);
    _activeFileIndex = _files.length - 1;
    notifyListeners();
  }

  String _generateFileName() {
    final existing = _files.map((f) => f.name).toSet();
    if (!existing.contains('main.cpp')) return 'main.cpp';
    int i = 1;
    while (existing.contains('file$i.cpp')) i++;
    return 'file$i.cpp';
  }

  void switchToFile(int index) {
    if (index < 0 || index >= _files.length) return;
    _activeFileIndex = index;
    final controller = _controllers[_files[index].id];
    if (controller != null) _updateCursorPosition(controller);
    notifyListeners();
  }

  Future<void> closeFile(int index) async {
    if (index < 0 || index >= _files.length) return;
    final file = _files[index];

    final controller = _controllers.remove(file.id);
    controller?.dispose();
    _undoStacks.remove(file.id);
    _redoStacks.remove(file.id);
    _files.removeAt(index);

    await StorageService.deleteFileContent(file.id);

    if (_files.isEmpty) {
      createNewFile();
      return;
    }

    if (_activeFileIndex >= _files.length) {
      _activeFileIndex = _files.length - 1;
    }

    notifyListeners();
  }

  void renameFile(int index, String newName) {
    if (index < 0 || index >= _files.length) return;
    _files[index] = _files[index].copyWith(
      name: newName,
      hasUnsavedChanges: true,
    );
    notifyListeners();
  }

  void setFileContent(int index, String content) {
    if (index < 0 || index >= _files.length) return;
    final file = _files[index];
    final controller = _controllers[file.id];
    if (controller != null) {
      controller.text = content;
    }
    _files[index] = file.copyWith(
      content: content,
      hasUnsavedChanges: true,
    );
    notifyListeners();
  }

  Future<void> openFileFromDisk(String path, String content, String fileName) async {
    if (_files.length >= AppSizes.maxTabs) {
      notifyListeners();
      return;
    }
    final id = generateFileId();
    final file = CodeFile(
      id: id,
      name: fileName,
      content: content,
      hasUnsavedChanges: false,
      filePath: path,
    );
    _addFileInternal(file);
    _activeFileIndex = _files.length - 1;
    await StorageService.addRecentFile(path);
    notifyListeners();
  }

  void insertSnippet(String code) {
    final controller = activeController;
    if (controller == null) return;

    final selection = controller.selection;
    final text = controller.text;

    String newText;
    int newOffset;

    if (text.trim().isEmpty) {
      newText = code;
      newOffset = code.length;
    } else if (selection.isValid) {
      final before = text.substring(0, selection.start);
      final after = text.substring(selection.end);
      newText = '$before$code$after';
      newOffset = selection.start + code.length;
    } else {
      newText = text + code;
      newOffset = newText.length;
    }

    controller.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: newOffset),
    );
  }

  // ─── Undo / Redo ──────────────────────────────────────────────────────
  void undo() {
    final file = activeFile;
    if (file == null) return;
    final stack = _undoStacks[file.id];
    if (stack == null || stack.isEmpty) return;

    final controller = _controllers[file.id];
    if (controller == null) return;

    final currentText = controller.text;
    _redoStacks[file.id] = [...(_redoStacks[file.id] ?? []), currentText];

    final previous = stack.removeLast();
    controller.value = TextEditingValue(
      text: previous,
      selection: TextSelection.collapsed(offset: previous.length.clamp(0, previous.length)),
    );

    _files[_activeFileIndex] = file.copyWith(content: previous, hasUnsavedChanges: true);
    notifyListeners();
  }

  void redo() {
    final file = activeFile;
    if (file == null) return;
    final stack = _redoStacks[file.id];
    if (stack == null || stack.isEmpty) return;

    final controller = _controllers[file.id];
    if (controller == null) return;

    final currentText = controller.text;
    _undoStacks[file.id] = [...(_undoStacks[file.id] ?? []), currentText];

    final next = stack.removeLast();
    controller.value = TextEditingValue(
      text: next,
      selection: TextSelection.collapsed(offset: next.length.clamp(0, next.length)),
    );

    _files[_activeFileIndex] = file.copyWith(content: next, hasUnsavedChanges: true);
    notifyListeners();
  }

  // ─── Compilation ──────────────────────────────────────────────────────
  Future<void> compile() async {
    final file = activeFile;
    final controller = activeController;
    if (file == null || controller == null) return;
    if (_compilationState == CompilationState.compiling) return;

    _compilationState = CompilationState.compiling;
    _lastResult = null;
    _errors = [];
    _activeBottomTab = 1; // switch to output
    notifyListeners();

    final code = controller.text;
    final settings = _settings;

    final result = await _compilerService.compile(
      code: code,
      compiler: settings?.compiler ?? AppStrings.defaultCompiler,
      cppStandard: settings?.cppStandard ?? AppStrings.defaultStandard,
      stdin: _stdinInput,
      extraFlags: settings?.compilerFlags ?? AppStrings.defaultFlags,
      timeoutSeconds: settings?.timeout ?? 30,
    );

    _lastResult = result;

    if (result.isNetworkError) {
      _compilationState = CompilationState.networkError;
    } else if (result.compilationFailed) {
      _compilationState = CompilationState.error;
      _errors = ErrorParser.parse(result.compilerMessage);
      if (_errors.isNotEmpty) _activeBottomTab = 2;
    } else if (!result.success) {
      _compilationState = CompilationState.error;
    } else {
      _compilationState = CompilationState.success;
    }

    notifyListeners();

    // Auto-reset to idle after a few seconds
    await Future.delayed(const Duration(seconds: 3));
    if (_compilationState != CompilationState.compiling) {
      _compilationState = CompilationState.idle;
      notifyListeners();
    }
  }

  // ─── Jump to Line ─────────────────────────────────────────────────────
  void jumpToLine(int lineNumber) {
    final controller = activeController;
    if (controller == null) return;

    final text = controller.text;
    final lines = text.split('\n');

    if (lineNumber < 1 || lineNumber > lines.length) return;

    int offset = 0;
    for (int i = 0; i < lineNumber - 1; i++) {
      offset += lines[i].length + 1;
    }

    controller.selection = TextSelection.collapsed(offset: offset);
    _cursorLine = lineNumber;
    _cursorColumn = 1;

    // Scroll to line
    final fontSize = _settings?.fontSize ?? 14.0;
    final lineHeight = fontSize * 1.5;
    final targetScroll = (lineNumber - 1) * lineHeight;

    _editorScrollController?.animateTo(
      targetScroll.clamp(0.0, _editorScrollController!.position.maxScrollExtent),
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );

    // Flash the line
    _flashLine = lineNumber;
    notifyListeners();

    _flashTimer?.cancel();
    _flashTimer = Timer(const Duration(milliseconds: 1500), () {
      _flashLine = null;
      notifyListeners();
    });
  }

  // ─── Find & Replace ───────────────────────────────────────────────────
  void toggleFindReplace() {
    _showFindReplace = !_showFindReplace;
    if (!_showFindReplace) {
      _searchQuery = '';
      _matchPositions = [];
      _currentMatchIndex = 0;
    }
    notifyListeners();
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    _findMatches();
    notifyListeners();
  }

  void setReplaceQuery(String query) {
    _replaceQuery = query;
    notifyListeners();
  }

  void setSearchOptions({bool? caseSensitive, bool? wholeWord, bool? useRegex}) {
    if (caseSensitive != null) _caseSensitive = caseSensitive;
    if (wholeWord != null) _wholeWord = wholeWord;
    if (useRegex != null) _useRegex = useRegex;
    _findMatches();
    notifyListeners();
  }

  void _findMatches() {
    if (_searchQuery.isEmpty) {
      _matchPositions = [];
      _currentMatchIndex = 0;
      return;
    }

    final controller = activeController;
    if (controller == null) return;

    final text = controller.text;
    _matchPositions = [];

    try {
      RegExp pattern;
      if (_useRegex) {
        pattern = RegExp(
          _searchQuery,
          caseSensitive: _caseSensitive,
          multiLine: true,
        );
      } else {
        var escaped = RegExp.escape(_searchQuery);
        if (_wholeWord) escaped = r'\b' + escaped + r'\b';
        pattern = RegExp(escaped, caseSensitive: _caseSensitive);
      }

      for (final match in pattern.allMatches(text)) {
        _matchPositions.add(match.start);
      }
    } catch (_) {}

    if (_currentMatchIndex >= _matchPositions.length) {
      _currentMatchIndex = 0;
    }

    if (_matchPositions.isNotEmpty) {
      _scrollToMatch(_currentMatchIndex);
    }
  }

  void nextMatch() {
    if (_matchPositions.isEmpty) return;
    _currentMatchIndex = (_currentMatchIndex + 1) % _matchPositions.length;
    _scrollToMatch(_currentMatchIndex);
    notifyListeners();
  }

  void previousMatch() {
    if (_matchPositions.isEmpty) return;
    _currentMatchIndex =
        (_currentMatchIndex - 1 + _matchPositions.length) % _matchPositions.length;
    _scrollToMatch(_currentMatchIndex);
    notifyListeners();
  }

  void _scrollToMatch(int matchIndex) {
    if (matchIndex >= _matchPositions.length) return;
    final controller = activeController;
    if (controller == null) return;

    final offset = _matchPositions[matchIndex];
    final end = offset + _searchQuery.length;
    controller.selection = TextSelection(baseOffset: offset, extentOffset: end);
  }

  void replaceCurrent() {
    if (_matchPositions.isEmpty || _searchQuery.isEmpty) return;
    final controller = activeController;
    if (controller == null) return;

    final text = controller.text;
    final offset = _matchPositions[_currentMatchIndex];
    final end = offset + _searchQuery.length;

    final newText = text.substring(0, offset) + _replaceQuery + text.substring(end);
    controller.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: offset + _replaceQuery.length),
    );

    _findMatches();
    notifyListeners();
  }

  void replaceAll() {
    if (_searchQuery.isEmpty) return;
    final controller = activeController;
    if (controller == null) return;

    try {
      RegExp pattern;
      if (_useRegex) {
        pattern = RegExp(_searchQuery, caseSensitive: _caseSensitive);
      } else {
        var escaped = RegExp.escape(_searchQuery);
        if (_wholeWord) escaped = r'\b' + escaped + r'\b';
        pattern = RegExp(escaped, caseSensitive: _caseSensitive);
      }

      final newText = controller.text.replaceAll(pattern, _replaceQuery);
      controller.value = TextEditingValue(
        text: newText,
        selection: TextSelection.collapsed(offset: 0),
      );

      _findMatches();
      notifyListeners();
    } catch (_) {}
  }

  // ─── Bottom Panel ─────────────────────────────────────────────────────
  void setActiveBottomTab(int tab) {
    _activeBottomTab = tab.clamp(0, 2);
    notifyListeners();
  }

  void setStdinInput(String input) {
    _stdinInput = input;
    notifyListeners();
  }

  void clearStdin() {
    _stdinInput = '';
    notifyListeners();
  }

  // ─── Auto Save ────────────────────────────────────────────────────────
  void _startAutoSave() {
    _autoSaveTimer?.cancel();
    _autoSaveTimer = Timer.periodic(const Duration(seconds: 30), (_) => _autoSave());
  }

  Future<void> _autoSave() async {
    for (final file in _files) {
      if (file.hasUnsavedChanges) {
        final controller = _controllers[file.id];
        if (controller != null) {
          await StorageService.saveFileContent(file.id, controller.text);
        }
      }
    }
    await StorageService.saveSession(
      openFiles: _files,
      activeFileIndex: _activeFileIndex,
    );
  }

  Future<void> saveCurrentFile() async {
    final file = activeFile;
    if (file == null) return;
    final controller = _controllers[file.id];
    if (controller == null) return;

    await StorageService.saveFileContent(file.id, controller.text);
    final idx = _activeFileIndex;
    _files[idx] = _files[idx].copyWith(
      hasUnsavedChanges: false,
      content: controller.text,
    );
    notifyListeners();
  }

  // ─── Dispose ──────────────────────────────────────────────────────────
  @override
  void dispose() {
    _autoSaveTimer?.cancel();
    _flashTimer?.cancel();
    for (final controller in _controllers.values) {
      controller.dispose();
    }
    _controllers.clear();
    _compilerService.dispose();
    super.dispose();
  }
}
