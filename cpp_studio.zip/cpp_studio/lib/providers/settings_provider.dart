import 'package:flutter/material.dart';
import '../models/app_settings.dart';
import '../services/storage_service.dart';
import '../theme/editor_themes.dart';

class SettingsProvider extends ChangeNotifier {
  AppSettings _settings = AppSettings.defaults();
  EditorThemeData _editorTheme = EditorThemes.vsDarkPlus;

  AppSettings get settings => _settings;
  EditorThemeData get editorTheme => _editorTheme;

  // Convenience getters
  double get fontSize => _settings.fontSize;
  String get fontFamily => _settings.fontFamily;
  int get tabSize => _settings.tabSize;
  bool get wordWrap => _settings.wordWrap;
  bool get autoIndent => _settings.autoIndent;
  bool get bracketAutoClose => _settings.bracketAutoClose;
  bool get showLineNumbers => _settings.showLineNumbers;
  bool get highlightCurrentLine => _settings.highlightCurrentLine;
  String get theme => _settings.theme;
  String get compiler => _settings.compiler;
  String get cppStandard => _settings.cppStandard;
  String get compilerFlags => _settings.compilerFlags;
  int get timeout => _settings.timeout;
  bool get isDarkTheme => _settings.isDarkTheme;

  Future<void> loadSettings() async {
    try {
      _settings = await StorageService.loadSettings();
      _editorTheme = EditorThemes.fromString(_settings.theme);
    } catch (_) {
      _settings = AppSettings.defaults();
      _editorTheme = EditorThemes.vsDarkPlus;
    }
    notifyListeners();
  }

  Future<void> _save() async {
    await StorageService.saveSettings(_settings);
  }

  void setFontSize(double size) {
    _settings = _settings.copyWith(fontSize: size.clamp(10.0, 24.0));
    _save();
    notifyListeners();
  }

  void setFontFamily(String family) {
    _settings = _settings.copyWith(fontFamily: family);
    _save();
    notifyListeners();
  }

  void setTabSize(int size) {
    _settings = _settings.copyWith(tabSize: size);
    _save();
    notifyListeners();
  }

  void setWordWrap(bool value) {
    _settings = _settings.copyWith(wordWrap: value);
    _save();
    notifyListeners();
  }

  void setAutoIndent(bool value) {
    _settings = _settings.copyWith(autoIndent: value);
    _save();
    notifyListeners();
  }

  void setBracketAutoClose(bool value) {
    _settings = _settings.copyWith(bracketAutoClose: value);
    _save();
    notifyListeners();
  }

  void setShowLineNumbers(bool value) {
    _settings = _settings.copyWith(showLineNumbers: value);
    _save();
    notifyListeners();
  }

  void setHighlightCurrentLine(bool value) {
    _settings = _settings.copyWith(highlightCurrentLine: value);
    _save();
    notifyListeners();
  }

  void setTheme(String themeKey) {
    _settings = _settings.copyWith(theme: themeKey);
    _editorTheme = EditorThemes.fromString(themeKey);
    _save();
    notifyListeners();
  }

  void setCompiler(String compiler) {
    _settings = _settings.copyWith(compiler: compiler);
    _save();
    notifyListeners();
  }

  void setCppStandard(String standard) {
    _settings = _settings.copyWith(cppStandard: standard);
    _save();
    notifyListeners();
  }

  void setCompilerFlags(String flags) {
    _settings = _settings.copyWith(compilerFlags: flags);
    _save();
    notifyListeners();
  }

  void setTimeout(int seconds) {
    _settings = _settings.copyWith(timeout: seconds);
    _save();
    notifyListeners();
  }

  void resetToDefaults() {
    _settings = AppSettings.defaults();
    _editorTheme = EditorThemes.vsDarkPlus;
    _save();
    notifyListeners();
  }
}
